# Rideizzy Web

Web version of the Rideizzy mobile app, built with **React + Vite + TypeScript**. It talks to the
**Rideizzy API** (`../../rideizzy-api`), which stores everything in **Turso**. People create an account with an
email and password; there is no Firebase and no Google sign-in.

## Run it

```bash
npm install
cp .env.example .env     # set VITE_API_URL
npm run dev              # http://localhost:5173
```

Production build: `npm run build` (output in `dist/`), preview with `npm run preview`.

## Configure

Edit `.env`:

| Variable | Meaning |
| --- | --- |
| `VITE_API_URL` | Address of the running Rideizzy API, e.g. `http://localhost:8000` |

The API must list this site's address in its `ALLOWED_ORIGINS`.

## Deploy

It is a static site. Upload `dist/` to Netlify, Vercel, Cloudflare Pages
or any static host. `public/_redirects` (Netlify/Cloudflare) and `vercel.json` already
rewrite all paths to `index.html` so deep links and refreshes work.

## What maps to what

| Mobile screen | Web route |
| --- | --- |
| Login / Role selection | shown automatically when signed out / no profile |
| RidesHome (map + "Where to?") | `/rides` |
| RequestRide | `/rides/request` |
| FindingDriver (status + live map) | `/rides/:rideId` |
| RequestDelivery / DeliveryTracking | `/delivery/request`, `/delivery/:deliveryId` |
| SchoolTrips / RequestTrip | `/school`, `/school/request` |
| RequestFlight / FlightRequestStatus | `/travel`, `/travel/:requestId` |
| AgentQueue / SubmitQuote | `/agency`, `/agency/quote/:requestId` |
| AdminQuoteApproval / AdminAgencies | `/admin`, `/admin/agencies` |
| Notifications | `/notifications` |

Navigation follows the same role rules as the app: riders see Rides and Travel,
school admins see School, agents see Agency, admins see Admin, everyone sees Alerts. A
sidebar is used on desktop and a bottom tab bar on phones. Pages a role can't use redirect
back home.

## Differences from the mobile app

- **Maps** use Leaflet with OpenStreetMap tiles instead of `react-native-maps`, so no map
  API key is needed. Address autocomplete still goes through your backend's Google Places
  endpoints.
- **Location**: uses the browser's geolocation (asks for permission) and falls back to
  Kampala if denied.
- **Sign-in** is email + password; the API issues a 7-day session token. Travel agencies enter a one-time invite code (from an admin) to get the Agency tab.
- **Live driver location** is refreshed by polling the API every 3 seconds (Firebase Realtime Database is gone).
- **Fares** are now calculated by the server; the client's estimate is only for display.
- **Errors and confirmations** show as toasts instead of native alerts, and failed
  requests now show a message instead of failing silently.
- **Date fields** use the browser's date picker.
- Polling stops once a ride or delivery has finished.
- A school admin with no `schoolId` on their profile now sees an explanation instead of an
  empty screen (the mobile README lists this as an open gap).

## Not built yet (same as the mobile app)

Driver-side screens, school trip vehicle/driver assignment UI, wallet and payments, and
push notifications. The notifications page polls every 10 seconds, as in the app.
