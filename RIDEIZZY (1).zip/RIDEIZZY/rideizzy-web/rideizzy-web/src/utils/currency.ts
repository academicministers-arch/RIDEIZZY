/** Formats a number as Ugandan Shillings, e.g. 12500 -> "UGX 12,500". Always whole shillings. */
export function formatUGX(amount: number | null | undefined): string {
  if (amount == null) return "—";
  return `UGX ${Math.round(amount).toLocaleString("en-UG")}`;
}

/** Quotes can be in other currencies; only UGX gets the shilling formatting. */
export function formatMoney(price: number, currency: string): string {
  return currency === "UGX" ? formatUGX(price) : `${price} ${currency}`;
}
