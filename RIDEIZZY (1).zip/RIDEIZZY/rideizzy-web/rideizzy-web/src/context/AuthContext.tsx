import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api } from "../services/api";
import { session, setSessionExpiredHandler } from "../services/session";

export type Role = "rider" | "driver" | "parent" | "school_admin" | "agent" | "admin";

export interface Profile {
  uid?: string;
  name: string;
  email: string;
  roles: Role[];
  schoolId?: string;
  agencyId?: string;
}

export interface AuthUser {
  name: string;
  email: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (name: string, email: string, password: string, inviteCode?: string) => Promise<void>;
  signOut: () => void;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const clear = useCallback(() => {
    session.clear();
    setUser(null);
    setProfile(null);
  }, []);

  const refreshProfile = useCallback(async () => {
    const { data } = await api.get("/auth/me");
    setUser(data.user);
    setProfile(data.profile); // null for a brand-new user who still has to pick a role
  }, []);

  // On first load, restore the session if we have a token.
  useEffect(() => {
    setSessionExpiredHandler(clear);
    let cancelled = false;
    (async () => {
      if (session.get()) {
        try {
          await refreshProfile();
        } catch {
          if (!cancelled) clear();
        }
      }
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
      setSessionExpiredHandler(null);
    };
  }, [clear, refreshProfile]);

  function startSession(data: { token: string; user: AuthUser; profile: Profile | null }) {
    session.set(data.token);
    setUser(data.user);
    setProfile(data.profile);
  }

  async function signIn(email: string, password: string) {
    const { data } = await api.post("/auth/login", { email, password });
    startSession(data);
  }

  async function signUp(name: string, email: string, password: string, inviteCode?: string) {
    const { data } = await api.post("/auth/register", { name, email, password, invite_code: inviteCode || undefined });
    startSession(data);
  }

  function signOut() {
    clear();
  }

  return (
    <AuthContext.Provider value={{ user, profile, loading, signIn, signUp, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
