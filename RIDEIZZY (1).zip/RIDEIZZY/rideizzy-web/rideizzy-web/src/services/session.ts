// Our own login session: a token issued by the Rideizzy API after sign-in.
const KEY = "rideizzy_token";

export const session = {
  get(): string | null {
    try { return localStorage.getItem(KEY); } catch { return null; }
  },
  set(token: string) {
    try { localStorage.setItem(KEY, token); } catch { /* storage blocked: session lasts until reload */ }
  },
  clear() {
    try { localStorage.removeItem(KEY); } catch { /* ignore */ }
  },
};

type Listener = () => void;
let onExpired: Listener | null = null;
/** AuthContext registers here so any 401 from the API signs the user out. */
export function setSessionExpiredHandler(fn: Listener | null) {
  onExpired = fn;
}
export function notifySessionExpired() {
  onExpired?.();
}
