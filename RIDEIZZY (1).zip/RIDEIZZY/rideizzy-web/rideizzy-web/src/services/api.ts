import axios from "axios";
import { notifySessionExpired, session } from "./session";

export const API_URL: string = (import.meta.env.VITE_API_URL ?? "http://localhost:8000").replace(/\/$/, "");

export const api = axios.create({ baseURL: API_URL });

// Attach our session token to every request.
api.interceptors.request.use((config) => {
  const token = session.get();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// An expired/invalid session sends the user back to the login screen.
api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (axios.isAxiosError(err) && err.response?.status === 401 && session.get()) {
      notifySessionExpired();
    }
    return Promise.reject(err);
  }
);

/** Turn any thrown error into a readable message for the UI. */
export function errorMessage(err: unknown): string {
  if (axios.isAxiosError(err)) {
    const detail = err.response?.data?.detail;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail) && detail[0]?.msg) return String(detail[0].msg);
    if (!err.response) return "Can't reach the server. Check your connection or the API address.";
    return `Request failed (${err.response.status})`;
  }
  if (err instanceof Error) return err.message;
  return "Something went wrong";
}
