import { useState } from "react";
import PlaceAutocompleteInput from "./PlaceAutocompleteInput";
import { PlaceDetails } from "../services/maps";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";
import { formatUGX } from "../utils/currency";

export interface VehicleClass {
  key: string;
  label: string;
  note: string;
}

export interface Estimate {
  distance_km: number;
  duration_min: number;
  estimates: Record<string, number>;
}

interface Props {
  dropoffPlaceholder: string;
  chooseTitle: string;
  classes: VehicleClass[];
  defaultClass: string;
  confirmLabel: string;
  busyLabel: string;
  extraValid?: boolean;
  children?: React.ReactNode; // extra fields shown between the classes and the button
  onConfirm: (args: {
    pickup: PlaceDetails;
    dropoff: PlaceDetails;
    vehicleClass: string;
    estimatedFare: number | null;
  }) => Promise<void>;
}

/**
 * Shared flow for "ride" and "delivery" requests: pick pickup + dropoff, get a
 * fare estimate from the backend, choose a vehicle class, confirm.
 */
export default function TripPlanner({
  dropoffPlaceholder,
  chooseTitle,
  classes,
  defaultClass,
  confirmLabel,
  busyLabel,
  extraValid = true,
  children,
  onConfirm,
}: Props) {
  const toast = useToast();
  const [pickup, setPickup] = useState<PlaceDetails | null>(null);
  const [dropoff, setDropoff] = useState<PlaceDetails | null>(null);
  const [vehicleClass, setVehicleClass] = useState(defaultClass);
  const [estimate, setEstimate] = useState<Estimate | null>(null);
  const [estimating, setEstimating] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function fetchEstimate(p: PlaceDetails, d: PlaceDetails) {
    setEstimating(true);
    try {
      const { data } = await api.post("/rides/estimate", { pickup: p, dropoff: d });
      setEstimate(data);
    } catch (err) {
      setEstimate(null);
      toast(errorMessage(err), "error");
    } finally {
      setEstimating(false);
    }
  }

  async function handlePickup(place: PlaceDetails) {
    setPickup(place);
    if (dropoff) await fetchEstimate(place, dropoff);
  }

  async function handleDropoff(place: PlaceDetails) {
    setDropoff(place);
    if (pickup) await fetchEstimate(pickup, place);
  }

  async function handleConfirm() {
    if (!pickup || !dropoff) return;
    setSubmitting(true);
    try {
      await onConfirm({
        pickup,
        dropoff,
        vehicleClass,
        estimatedFare: estimate?.estimates?.[vehicleClass] ?? null,
      });
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="stack-lg">
      <div>
        <PlaceAutocompleteInput placeholder="Pickup location" onSelect={handlePickup} />
        <PlaceAutocompleteInput placeholder={dropoffPlaceholder} onSelect={handleDropoff} />
        {estimating && <span className="spinner spinner-sm" />}
        {estimate && (
          <p className="trip-meta">
            {estimate.distance_km} km · ~{Math.round(estimate.duration_min)} min
          </p>
        )}
      </div>

      <div>
        <h2 className="section-title">{chooseTitle}</h2>
        <div className="stack">
          {classes.map((v) => (
            <button
              key={v.key}
              type="button"
              className={`option option-row${vehicleClass === v.key ? " selected" : ""}`}
              onClick={() => setVehicleClass(v.key)}
              aria-pressed={vehicleClass === v.key}
            >
              <span>
                <span className="option-label">{v.label}</span>
                <span className="option-note">{v.note}</span>
              </span>
              <span className="option-price">{estimate ? formatUGX(estimate.estimates[v.key]) : "—"}</span>
            </button>
          ))}
        </div>
      </div>

      {children}

      <button
        className="btn btn-primary btn-block"
        onClick={handleConfirm}
        disabled={submitting || !estimate || !extraValid}
      >
        {submitting ? busyLabel : confirmLabel}
      </button>
    </div>
  );
}
