import { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

export interface MapPoint {
  lat: number;
  lng: number;
  label?: string;
}

// Leaflet's default marker images break under bundlers, so draw our own pin.
const pinIcon = L.divIcon({
  className: "map-pin",
  html: '<span class="map-pin-dot"></span>',
  iconSize: [24, 24],
  iconAnchor: [12, 12],
});

function Recenter({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom, { animate: true });
  }, [center[0], center[1], zoom, map]);
  return null;
}

interface Props {
  center: MapPoint;
  zoom?: number;
  marker?: MapPoint | null;
}

/** Full-size map with one marker. Replaces react-native-maps' MapView. */
export default function MapView({ center, zoom = 15, marker }: Props) {
  const c: [number, number] = [center.lat, center.lng];
  return (
    <MapContainer center={c} zoom={zoom} scrollWheelZoom className="map">
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <Recenter center={c} zoom={zoom} />
      {marker && (
        <Marker position={[marker.lat, marker.lng]} icon={pinIcon}>
          {marker.label && <Popup>{marker.label}</Popup>}
        </Marker>
      )}
    </MapContainer>
  );
}
