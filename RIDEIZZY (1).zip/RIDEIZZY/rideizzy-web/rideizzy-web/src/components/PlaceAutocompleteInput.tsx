import { useEffect, useRef, useState } from "react";
import { searchPlaces, getPlaceDetails, PlaceSuggestion, PlaceDetails } from "../services/maps";
import { errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";

interface Props {
  label?: string;
  placeholder: string;
  onSelect: (place: PlaceDetails) => void;
}

// Debounced Google Places autocomplete (through the backend). Type a few
// letters, pick a suggestion, get real lat/lng back via onSelect.
export default function PlaceAutocompleteInput({ label, placeholder, onSelect }: Props) {
  const toast = useToast();
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<PlaceSuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (selected) return; // don't re-search right after picking a result
    if (debounceRef.current) clearTimeout(debounceRef.current);

    debounceRef.current = setTimeout(async () => {
      if (query.trim().length < 2) {
        setSuggestions([]);
        return;
      }
      setLoading(true);
      try {
        setSuggestions(await searchPlaces(query));
      } catch (err) {
        setSuggestions([]);
        toast(errorMessage(err), "error");
      } finally {
        setLoading(false);
      }
    }, 400);

    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query, selected]);

  async function handleSelect(s: PlaceSuggestion) {
    setSelected(true);
    setQuery(s.description);
    setSuggestions([]);
    try {
      const details = await getPlaceDetails(s.place_id);
      onSelect({ ...details, address: details.address || s.description });
    } catch (err) {
      setSelected(false);
      toast(errorMessage(err), "error");
    }
  }

  return (
    <div className="place-input">
      {label && <label className="label">{label}</label>}
      <div className="place-input-field">
        <input
          className="input"
          placeholder={placeholder}
          value={query}
          autoComplete="off"
          onChange={(e) => {
            setSelected(false);
            setQuery(e.target.value);
          }}
        />
        {loading && <span className="spinner spinner-sm place-input-spinner" />}
      </div>
      {suggestions.length > 0 && (
        <ul className="suggestions">
          {suggestions.map((s) => (
            <li key={s.place_id}>
              <button type="button" className="suggestion-row" onClick={() => handleSelect(s)}>
                {s.description}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
