import { NavLink, Outlet } from "react-router-dom";
import { useAuth, Role } from "../context/AuthContext";

interface NavItem {
  to: string;
  label: string;
  icon: string;
  roles?: Role[]; // user needs at least one of these; omitted = everyone
}

// Same tab logic as the mobile app: what you see depends on your roles.
const NAV: NavItem[] = [
  { to: "/rides", label: "Rides", icon: "🚕", roles: ["rider"] },
  { to: "/school", label: "School", icon: "🚌", roles: ["school_admin"] },
  { to: "/travel", label: "Travel", icon: "✈️", roles: ["rider"] },
  { to: "/agency", label: "Agency", icon: "🧳", roles: ["agent"] },
  { to: "/admin", label: "Admin", icon: "🛡️", roles: ["admin"] },
  { to: "/notifications", label: "Alerts", icon: "🔔" },
];

export function navForRoles(roles: Role[]) {
  return NAV.filter((n) => !n.roles || n.roles.some((r) => roles.includes(r)));
}

export default function AppShell() {
  const { profile, user, signOut } = useAuth();
  const items = navForRoles(profile?.roles ?? []);
  const isAgent = profile?.roles.includes("agent") ?? false;

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">Rideizzy</div>
        <nav className="sidebar-nav">
          {items.map((n) => (
            <NavLink key={n.to} to={n.to} className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}>
              <span className="nav-icon" aria-hidden>{n.icon}</span>
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-user">
          <div className="sidebar-user-name">{profile?.name || user?.name || "Signed in"}</div>
          <div className="sidebar-user-email">{profile?.email || user?.email}</div>
          {!isAgent && <NavLink to="/invite" className="btn btn-ghost btn-sm">Have an invite code?</NavLink>}
          <button className="btn btn-ghost btn-sm" onClick={signOut}>Sign out</button>
        </div>
      </aside>

      <div className="main">
        <header className="topbar">
          <span className="brand brand-sm">Rideizzy</span>
          <span>
            {!isAgent && <NavLink to="/invite" className="btn btn-ghost btn-sm">Invite code</NavLink>}
            <button className="btn btn-ghost btn-sm" onClick={signOut}>Sign out</button>
          </span>
        </header>
        <main className="content">
          <Outlet />
        </main>
      </div>

      <nav className="tabbar" aria-label="Main">
        {items.map((n) => (
          <NavLink key={n.to} to={n.to} className={({ isActive }) => `tab${isActive ? " active" : ""}`}>
            <span className="tab-icon" aria-hidden>{n.icon}</span>
            <span className="tab-label">{n.label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
