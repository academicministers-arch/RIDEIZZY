import { useEffect, useRef, useState } from "react";
import { api } from "./services/api";

/**
 * Calls `fn` now and then every `ms` milliseconds until unmounted. Errors are
 * swallowed (a missed poll just retries next tick) so they never become
 * unhandled promise rejections.
 */
export function usePolling(fn: () => Promise<void> | void, ms: number, deps: unknown[] = []) {
  const saved = useRef(fn);
  saved.current = fn;

  useEffect(() => {
    let cancelled = false;
    const tick = async () => {
      try {
        if (!cancelled) await saved.current();
      } catch {
        /* retry on next tick */
      }
    };
    tick();
    const id = setInterval(tick, ms);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ms, ...deps]);
}

/**
 * Driver position, refreshed every few seconds from the API while `active`.
 * `path` is e.g. `/rides/<id>/driver-location`; pass null until a driver is assigned.
 */
export function useDriverLocation(path: string | null | undefined, active: boolean) {
  const [loc, setLoc] = useState<{ lat: number; lng: number } | null>(null);

  usePolling(
    async () => {
      if (!path || !active) return;
      const { data } = await api.get(path);
      if (data) setLoc({ lat: data.lat, lng: data.lng });
    },
    3000,
    [path, active]
  );

  return loc;
}
