import { BrowserRouter, Navigate, NavLink, Outlet, Route, Routes } from "react-router-dom";
import { useAuth, Role } from "./context/AuthContext";
import AppShell, { navForRoles } from "./components/AppShell";

import LoginPage from "./pages/LoginPage";
import RoleSelectionPage from "./pages/RoleSelectionPage";
import RidesHomePage from "./pages/RidesHomePage";
import RequestRidePage from "./pages/RequestRidePage";
import FindingDriverPage from "./pages/FindingDriverPage";
import RequestDeliveryPage from "./pages/RequestDeliveryPage";
import DeliveryTrackingPage from "./pages/DeliveryTrackingPage";
import SchoolTripsPage from "./pages/SchoolTripsPage";
import RequestTripPage from "./pages/RequestTripPage";
import RequestFlightPage from "./pages/RequestFlightPage";
import FlightRequestStatusPage from "./pages/FlightRequestStatusPage";
import AgentQueuePage from "./pages/AgentQueuePage";
import SubmitQuotePage from "./pages/SubmitQuotePage";
import AdminQuoteApprovalPage from "./pages/AdminQuoteApprovalPage";
import AdminAgenciesPage from "./pages/AdminAgenciesPage";
import NotificationsPage from "./pages/NotificationsPage";
import InvitePage from "./pages/InvitePage";

/** Only render children if the user holds at least one of the roles. */
function RequireRole({ roles }: { roles: Role[] }) {
  const { profile } = useAuth();
  const ok = roles.some((r) => profile?.roles.includes(r));
  return ok ? <Outlet /> : <Navigate to="/" replace />;
}

function AdminLayout() {
  return (
    <>
      <div className="subnav">
        <NavLink to="/admin" end className={({ isActive }) => `subnav-link${isActive ? " active" : ""}`}>
          Approvals
        </NavLink>
        <NavLink to="/admin/agencies" className={({ isActive }) => `subnav-link${isActive ? " active" : ""}`}>
          Agencies
        </NavLink>
      </div>
      <Outlet />
    </>
  );
}

/** Land on the first tab this user has, like the mobile app's first tab. */
function Home() {
  const { profile } = useAuth();
  const first = navForRoles(profile?.roles ?? [])[0];
  return <Navigate to={first?.to ?? "/notifications"} replace />;
}

function Splash() {
  return (
    <div className="center-screen">
      <span className="spinner" />
    </div>
  );
}

export default function App() {
  const { user, profile, loading } = useAuth();

  if (loading) return <Splash />;
  if (!user) return <LoginPage />;
  if (!profile) return <RoleSelectionPage />;

  return (
    <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <Routes>
        <Route element={<AppShell />}>
          <Route index element={<Home />} />

          <Route element={<RequireRole roles={["rider"]} />}>
            <Route path="rides" element={<RidesHomePage />} />
            <Route path="rides/request" element={<RequestRidePage />} />
            <Route path="rides/:rideId" element={<FindingDriverPage />} />
            <Route path="delivery/request" element={<RequestDeliveryPage />} />
            <Route path="delivery/:deliveryId" element={<DeliveryTrackingPage />} />
            <Route path="travel" element={<RequestFlightPage />} />
            <Route path="travel/:requestId" element={<FlightRequestStatusPage />} />
          </Route>

          <Route element={<RequireRole roles={["school_admin"]} />}>
            <Route path="school" element={<SchoolTripsPage />} />
            <Route path="school/request" element={<RequestTripPage />} />
          </Route>

          <Route element={<RequireRole roles={["agent"]} />}>
            <Route path="agency" element={<AgentQueuePage />} />
            <Route path="agency/quote/:requestId" element={<SubmitQuotePage />} />
          </Route>

          <Route element={<RequireRole roles={["admin"]} />}>
            <Route element={<AdminLayout />}>
              <Route path="admin" element={<AdminQuoteApprovalPage />} />
              <Route path="admin/agencies" element={<AdminAgenciesPage />} />
            </Route>
          </Route>

          <Route path="notifications" element={<NotificationsPage />} />
          <Route path="invite" element={<InvitePage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
