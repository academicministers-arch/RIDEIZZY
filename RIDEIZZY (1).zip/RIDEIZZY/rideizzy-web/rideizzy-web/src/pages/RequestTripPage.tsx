import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";

const VEHICLE_TYPES = ["coaster", "bus"];

export default function RequestTripPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const [destination, setDestination] = useState("");
  const [date, setDate] = useState("");
  const [passengerCount, setPassengerCount] = useState("");
  const [vehicleType, setVehicleType] = useState("coaster");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.post("/school/trips", {
        destination,
        date,
        passenger_count: parseInt(passengerCount, 10) || 0,
        vehicle_type: vehicleType,
        notes,
      });
      toast("Trip requested. We'll assign a vehicle and driver shortly.", "success");
      navigate("/school");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form className="page form" onSubmit={handleSubmit}>
      <h1 className="title">Request a Trip</h1>

      <label className="label">Destination</label>
      <input className="input" required value={destination} onChange={(e) => setDestination(e.target.value)} placeholder="e.g. National Museum" />

      <label className="label">Date</label>
      <input className="input" type="date" required value={date} onChange={(e) => setDate(e.target.value)} />

      <label className="label">Number of passengers</label>
      <input
        className="input"
        type="number"
        inputMode="numeric"
        min={1}
        required
        value={passengerCount}
        onChange={(e) => setPassengerCount(e.target.value)}
        placeholder="e.g. 40"
      />

      <label className="label">Vehicle type</label>
      <div className="grid-2">
        {VEHICLE_TYPES.map((v) => (
          <button
            key={v}
            type="button"
            className={`option option-center${vehicleType === v ? " selected" : ""}`}
            onClick={() => setVehicleType(v)}
            aria-pressed={vehicleType === v}
          >
            {v}
          </button>
        ))}
      </div>

      <label className="label">Notes (optional)</label>
      <input className="input" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Special requirements..." />

      <button className="btn btn-primary btn-block mt-lg" type="submit" disabled={submitting}>
        {submitting ? "Submitting…" : "Submit Trip Request"}
      </button>
    </form>
  );
}
