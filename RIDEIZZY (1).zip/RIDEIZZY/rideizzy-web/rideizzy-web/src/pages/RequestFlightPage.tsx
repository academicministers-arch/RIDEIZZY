import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";

export default function RequestFlightPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [departDate, setDepartDate] = useState("");
  const [passengers, setPassengers] = useState("1");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { data } = await api.post("/travel/requests", {
        origin,
        destination,
        depart_date: departDate,
        passengers: parseInt(passengers, 10) || 1,
        cabin_class: "economy",
      });
      navigate(`/travel/${data.request_id}`);
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form className="page form" onSubmit={handleSubmit}>
      <h1 className="title">Request a Flight</h1>
      <p className="subtitle">Our travel partner will send you a quote.</p>

      <div className="grid-2">
        <div>
          <label className="label">From</label>
          <input className="input" required placeholder="City or airport" value={origin} onChange={(e) => setOrigin(e.target.value)} />
        </div>
        <div>
          <label className="label">To</label>
          <input className="input" required placeholder="City or airport" value={destination} onChange={(e) => setDestination(e.target.value)} />
        </div>
        <div>
          <label className="label">Departure date</label>
          <input className="input" type="date" required value={departDate} onChange={(e) => setDepartDate(e.target.value)} />
        </div>
        <div>
          <label className="label">Passengers</label>
          <input
            className="input"
            type="number"
            inputMode="numeric"
            min={1}
            required
            value={passengers}
            onChange={(e) => setPassengers(e.target.value)}
          />
        </div>
      </div>

      <button className="btn btn-primary btn-block mt-lg" type="submit" disabled={submitting}>
        {submitting ? "Sending…" : "Send Request"}
      </button>
    </form>
  );
}
