import { FormEvent, useEffect, useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";

export default function SubmitQuotePage() {
  const { requestId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const toast = useToast();

  // The queue passes the request along; if the page was opened directly
  // (refresh or shared link), look it up in the queue instead.
  const [request, setRequest] = useState<any>((location.state as any)?.request ?? null);
  const [missing, setMissing] = useState(false);

  const [price, setPrice] = useState("");
  const [itinerary, setItinerary] = useState("");
  const [expiresAt, setExpiresAt] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (request) return;
    api
      .get("/travel/requests/queue")
      .then(({ data }) => {
        const match = data.find((r: any) => r.request_id === requestId);
        if (match) setRequest(match);
        else setMissing(true);
      })
      .catch((err) => toast(errorMessage(err), "error"));
  }, [request, requestId]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.post(`/travel/requests/${requestId}/quote`, {
        price: parseFloat(price) || 0,
        currency: "UGX",
        itinerary,
        expires_at: expiresAt,
      });
      toast("Quote submitted. Sent for admin approval before it reaches the traveler.", "success");
      navigate("/agency");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setSubmitting(false);
    }
  }

  if (missing) {
    return (
      <div className="page">
        <p className="empty">This request is no longer waiting for a quote.</p>
        <Link to="/agency" className="btn btn-ghost">Back to queue</Link>
      </div>
    );
  }
  if (!request) {
    return (
      <div className="page">
        <span className="spinner" />
      </div>
    );
  }

  return (
    <form className="page form" onSubmit={handleSubmit}>
      <h1 className="title">
        {request.origin} → {request.destination}
      </h1>
      <p className="subtitle">
        {request.depart_date} · {request.passengers} pax
      </p>

      <label className="label">Price (UGX)</label>
      <input
        className="input"
        type="number"
        inputMode="decimal"
        min={0}
        step="any"
        required
        value={price}
        onChange={(e) => setPrice(e.target.value)}
        placeholder="e.g. 3200000"
      />

      <label className="label">Itinerary details</label>
      <textarea
        className="input textarea"
        required
        value={itinerary}
        onChange={(e) => setItinerary(e.target.value)}
        placeholder="Flight numbers, layovers, times..."
      />

      <label className="label">Quote expires</label>
      <input className="input" type="date" required value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} />

      <button className="btn btn-primary btn-block mt-lg" type="submit" disabled={submitting}>
        {submitting ? "Sending…" : "Submit Quote for Approval"}
      </button>
    </form>
  );
}
