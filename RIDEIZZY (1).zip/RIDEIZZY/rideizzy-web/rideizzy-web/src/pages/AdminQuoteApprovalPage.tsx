import { useCallback, useEffect, useState } from "react";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";
import { formatMoney } from "../utils/currency";

export default function AdminQuoteApprovalPage() {
  const toast = useToast();
  const [quotes, setQuotes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [approving, setApproving] = useState<string | null>(null);

  const load = useCallback(() => {
    return api
      .get("/travel/admin/quotes/pending")
      .then(({ data }) => setQuotes(data))
      .catch((err) => toast(errorMessage(err), "error"))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function approve(quoteId: string) {
    setApproving(quoteId);
    try {
      await api.post(`/travel/admin/quotes/${quoteId}/approve`);
      toast("Approved. The traveler has been notified.", "success");
      await load();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setApproving(null);
    }
  }

  return (
    <div className="page">
      <h1 className="title">Quotes Awaiting Approval</h1>

      {loading && <span className="spinner" />}
      {!loading && quotes.length === 0 && <p className="empty">Nothing waiting on you right now.</p>}

      <div className="stack">
        {quotes.map((item) => (
          <div key={item.quote_id} className="card">
            <div className="price">{formatMoney(item.price, item.currency)}</div>
            <p className="itinerary">{item.itinerary}</p>
            <button className="btn btn-success mt-sm" disabled={approving === item.quote_id} onClick={() => approve(item.quote_id)}>
              {approving === item.quote_id ? "Approving…" : "Approve & Notify Traveler"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
