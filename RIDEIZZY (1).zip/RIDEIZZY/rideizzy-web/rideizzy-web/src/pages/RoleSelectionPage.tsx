import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";

const ROLE_OPTIONS = [
  { key: "rider", label: "I need rides or want to book flights" },
  { key: "school_admin", label: "I book transport trips for a school" },
  { key: "driver", label: "I'm a driver" },
];
// "agent" (travel agency staff) isn't self-selected: it comes from an admin's invite code.
// "admin" is switched on from the server with `npm run make-admin`.

export default function RoleSelectionPage() {
  const { refreshProfile, signOut } = useAuth();
  const toast = useToast();
  const [selected, setSelected] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  function toggle(key: string) {
    setSelected((prev) => (prev.includes(key) ? prev.filter((r) => r !== key) : [...prev, key]));
  }

  async function handleContinue() {
    setBusy(true);
    try {
      // Name and email come from the account itself (set at sign-up), not from this request.
      await api.post("/users/profile", { roles: selected });
      await refreshProfile();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="center-screen">
      <div className="card narrow">
        <h1 className="title">What brings you to Rideizzy?</h1>
        <p className="subtitle">Select all that apply. You can add more later.</p>

        <div className="stack">
          {ROLE_OPTIONS.map((opt) => (
            <button
              key={opt.key}
              type="button"
              className={`option${selected.includes(opt.key) ? " selected" : ""}`}
              onClick={() => toggle(opt.key)}
              aria-pressed={selected.includes(opt.key)}
            >
              {opt.label}
            </button>
          ))}
        </div>

        <button className="btn btn-primary btn-block mt-lg" disabled={selected.length === 0 || busy} onClick={handleContinue}>
          {busy ? "Saving…" : "Continue"}
        </button>
        <button className="btn btn-ghost btn-block mt-sm" onClick={signOut}>Use a different account</button>
      </div>
    </div>
  );
}
