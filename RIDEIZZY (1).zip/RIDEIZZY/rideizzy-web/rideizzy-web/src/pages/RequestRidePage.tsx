import { useNavigate } from "react-router-dom";
import TripPlanner, { VehicleClass } from "../components/TripPlanner";
import { api } from "../services/api";

const RIDE_CLASSES: VehicleClass[] = [
  { key: "motorbike", label: "Motorbike", note: "Fastest through traffic, 1 passenger" },
  { key: "economy", label: "Economy", note: "Affordable everyday rides" },
  { key: "comfort", label: "Comfort", note: "Newer cars, extra legroom" },
  { key: "xl", label: "XL", note: "For groups up to 6" },
];

export default function RequestRidePage() {
  const navigate = useNavigate();

  return (
    <div className="page">
      <h1 className="title">Request a Ride</h1>
      <TripPlanner
        dropoffPlaceholder="Where to?"
        chooseTitle="Choose a ride"
        classes={RIDE_CLASSES}
        defaultClass="economy"
        confirmLabel="Confirm Ride"
        busyLabel="Requesting…"
        onConfirm={async ({ pickup, dropoff, vehicleClass }) => {
          const { data } = await api.post("/rides/request", {
            pickup,
            dropoff,
            vehicle_class: vehicleClass,
          });
          navigate(`/rides/${data.ride_id}`);
        }}
      />
    </div>
  );
}
