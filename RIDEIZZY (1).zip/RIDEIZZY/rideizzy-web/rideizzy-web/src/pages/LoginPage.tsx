import { FormEvent, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { errorMessage } from "../services/api";

export default function LoginPage() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [inviteCode, setInviteCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const signingUp = mode === "signup";

  function switchMode() {
    setMode(signingUp ? "signin" : "signup");
    setError(null);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (signingUp && password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    setBusy(true);
    try {
      if (signingUp) await signUp(name.trim(), email.trim(), password, inviteCode.trim());
      else await signIn(email.trim(), password);
    } catch (err) {
      setError(errorMessage(err));
      setBusy(false);
    }
    // On success the app switches screens by itself, so there's nothing more to do here.
  }

  return (
    <div className="center-screen login">
      <form className="login-card" onSubmit={handleSubmit}>
        <h1 className="logo">Rideizzy</h1>
        <p className="tagline">Rides. School transport. Flights.</p>

        <h2 className="section-title" style={{ textAlign: "left" }}>
          {signingUp ? "Create your account" : "Sign in"}
        </h2>

        {signingUp && (
          <>
            <label className="label" htmlFor="name">Full name</label>
            <input id="name" className="input" required autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
          </>
        )}

        <label className="label" htmlFor="email">Email</label>
        <input
          id="email"
          className="input"
          type="email"
          required
          autoComplete="email"
          autoCapitalize="none"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <label className="label" htmlFor="password">{signingUp ? "Create a password" : "Password"}</label>
        <input
          id="password"
          className="input"
          type={showPassword ? "text" : "password"}
          required
          minLength={signingUp ? 8 : undefined}
          autoComplete={signingUp ? "new-password" : "current-password"}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <label className="muted" style={{ display: "flex", gap: 6, alignItems: "center", marginTop: 8, fontSize: 13 }}>
          <input type="checkbox" checked={showPassword} onChange={(e) => setShowPassword(e.target.checked)} />
          Show password
        </label>
        {signingUp && <p className="muted" style={{ fontSize: 13, marginTop: 6 }}>At least 8 characters.</p>}

        {signingUp && (
          <>
            <label className="label" htmlFor="invite">Agency invite code (only if you were given one)</label>
            <input
              id="invite"
              className="input"
              autoCapitalize="characters"
              placeholder="XXXXX-XXXXX"
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
            />
          </>
        )}

        {error && <p className="form-error" role="alert">{error}</p>}

        <button className="btn btn-primary btn-block mt-lg" type="submit" disabled={busy}>
          {busy ? (signingUp ? "Creating account…" : "Signing in…") : signingUp ? "Create account" : "Sign in"}
        </button>

        <button className="btn btn-ghost btn-block mt-sm" type="button" onClick={switchMode} disabled={busy}>
          {signingUp ? "Already have an account? Sign in" : "New here? Create an account"}
        </button>
      </form>
    </div>
  );
}
