import { useState } from "react";
import { useNavigate } from "react-router-dom";
import TripPlanner, { VehicleClass } from "../components/TripPlanner";
import { api } from "../services/api";

const DELIVERY_CLASSES: VehicleClass[] = [
  { key: "delivery_motorbike", label: "Motorbike Parcel", note: "Small packages, documents, food" },
  { key: "delivery_truck_small", label: "Small Truck", note: "A few boxes, small furniture move" },
  { key: "delivery_truck_large", label: "Large Truck", note: "Full house/office shifting" },
];

export default function RequestDeliveryPage() {
  const navigate = useNavigate();
  const [packageDescription, setPackageDescription] = useState("");
  const [recipientName, setRecipientName] = useState("");
  const [recipientPhone, setRecipientPhone] = useState("");

  return (
    <div className="page">
      <h1 className="title">Send a Package</h1>
      <TripPlanner
        dropoffPlaceholder="Delivery location"
        chooseTitle="What are you sending?"
        classes={DELIVERY_CLASSES}
        defaultClass="delivery_motorbike"
        confirmLabel="Confirm Delivery"
        busyLabel="Requesting…"
        extraValid={packageDescription.trim().length > 0}
        onConfirm={async ({ pickup, dropoff, vehicleClass }) => {
          const { data } = await api.post("/delivery/request", {
            pickup,
            dropoff,
            vehicle_class: vehicleClass,
            package_description: packageDescription,
            recipient_name: recipientName || null,
            recipient_phone: recipientPhone || null,
          });
          navigate(`/delivery/${data.delivery_id}`);
        }}
      >
        <div className="stack">
          <div>
            <label className="label">Package / load description</label>
            <input
              className="input"
              value={packageDescription}
              onChange={(e) => setPackageDescription(e.target.value)}
              placeholder="e.g. 2 boxes of clothes, or full 2-bedroom house move"
            />
          </div>
          <div className="grid-2">
            <div>
              <label className="label">Recipient name (optional)</label>
              <input className="input" value={recipientName} onChange={(e) => setRecipientName(e.target.value)} />
            </div>
            <div>
              <label className="label">Recipient phone (optional)</label>
              <input
                className="input"
                type="tel"
                inputMode="tel"
                value={recipientPhone}
                onChange={(e) => setRecipientPhone(e.target.value)}
              />
            </div>
          </div>
        </div>
      </TripPlanner>
    </div>
  );
}
