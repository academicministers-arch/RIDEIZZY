import { FormEvent, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";

/** Travel-agency staff enter the one-time code an admin gave them to unlock the Agency tab. */
export default function InvitePage() {
  const { profile, refreshProfile } = useAuth();
  const toast = useToast();
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await api.post("/auth/redeem-invite", { code });
      await refreshProfile();
      toast("Done. You now have agency access.", "success");
      setCode("");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
    }
  }

  if (profile?.roles.includes("agent")) {
    return (
      <div className="page">
        <h1 className="title">Agency access</h1>
        <p className="subtitle">Your account already has agency access. Open the Agency tab to see flight requests.</p>
      </div>
    );
  }

  return (
    <form className="page form" onSubmit={handleSubmit}>
      <h1 className="title">Enter invite code</h1>
      <p className="subtitle">Travel agencies get a one-time code from a Rideizzy admin.</p>
      <label className="label" htmlFor="code">Invite code</label>
      <input
        id="code"
        className="input"
        required
        autoCapitalize="characters"
        placeholder="XXXXX-XXXXX"
        value={code}
        onChange={(e) => setCode(e.target.value)}
      />
      <button className="btn btn-primary btn-block mt-lg" type="submit" disabled={busy || !code.trim()}>
        {busy ? "Checking…" : "Unlock agency access"}
      </button>
    </form>
  );
}
