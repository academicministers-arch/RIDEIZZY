import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";

export default function SchoolTripsPage() {
  const { profile } = useAuth();
  const toast = useToast();
  const [trips, setTrips] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!profile?.schoolId) return;
    setLoading(true);
    api
      .get(`/school/trips/${profile.schoolId}`)
      .then(({ data }) => setTrips(data))
      .catch((err) => toast(errorMessage(err), "error"))
      .finally(() => setLoading(false));
  }, [profile?.schoolId]);

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="title">School Trips</h1>
          <p className="subtitle">Request transport for a school trip or event.</p>
        </div>
        <Link to="/school/request" className="btn btn-primary">Request a Trip</Link>
      </div>

      {!profile?.schoolId && (
        <div className="notice notice-warn">
          Your account isn't linked to a school yet, so trips can't be listed or requested. Ask an admin to set your
          school.
        </div>
      )}

      {loading && <span className="spinner" />}

      <div className="stack">
        {!loading && trips.length === 0 && profile?.schoolId && <p className="empty">No trips requested yet.</p>}
        {trips.map((item) => (
          <div key={item.trip_id} className="card">
            <div className="card-title">{item.destination}</div>
            <p className="muted">
              {item.date} · {item.passenger_count} passengers · {item.vehicle_type}
            </p>
            <p className="muted">Status: {item.status}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
