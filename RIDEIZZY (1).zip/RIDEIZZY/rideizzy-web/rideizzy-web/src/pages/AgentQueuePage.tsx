import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";

export default function AgentQueuePage() {
  const toast = useToast();
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get("/travel/requests/queue")
      .then(({ data }) => setRequests(data))
      .catch((err) => toast(errorMessage(err), "error"))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="page">
      <h1 className="title">Flight Requests</h1>
      <p className="subtitle">Awaiting a quote from you.</p>

      {loading && <span className="spinner" />}
      {!loading && requests.length === 0 && <p className="empty">No pending requests right now.</p>}

      <div className="stack">
        {requests.map((item) => (
          <Link key={item.request_id} to={`/agency/quote/${item.request_id}`} state={{ request: item }} className="card card-link">
            <div className="card-title">
              {item.origin} → {item.destination}
            </div>
            <p className="muted">
              {item.depart_date} · {item.passengers} pax · {item.cabin_class}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
