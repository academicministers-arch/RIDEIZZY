import { useState } from "react";
import { api } from "../services/api";
import { usePolling } from "../hooks";

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loaded, setLoaded] = useState(false);

  usePolling(
    async () => {
      const { data } = await api.get("/notifications/me");
      setNotifications(data);
      setLoaded(true);
    },
    10000
  );

  return (
    <div className="page">
      <h1 className="title">Notifications</h1>
      {!loaded && <span className="spinner" />}
      {loaded && notifications.length === 0 && <p className="empty">You're all caught up.</p>}
      <div className="stack">
        {notifications.map((item) => (
          <div key={item.notification_id} className={`card${item.read ? "" : " card-unread"}`}>
            <div className="card-title">{item.title}</div>
            <p className="muted">{item.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
