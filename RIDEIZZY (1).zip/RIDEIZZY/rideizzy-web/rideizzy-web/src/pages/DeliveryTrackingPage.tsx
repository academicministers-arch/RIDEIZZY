import { useState } from "react";
import { useParams } from "react-router-dom";
import MapView from "../components/MapView";
import { api } from "../services/api";
import { usePolling, useDriverLocation } from "../hooks";
import { formatUGX } from "../utils/currency";

const STATUS_LABELS: Record<string, string> = {
  searching: "Finding a driver…",
  accepted: "Driver assigned - heading to pickup",
  picked_up: "Picked up - on the way",
  in_transit: "In transit",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

export default function DeliveryTrackingPage() {
  const { deliveryId } = useParams();
  const [delivery, setDelivery] = useState<any>(null);

  const finished = delivery?.status === "delivered" || delivery?.status === "cancelled";
  usePolling(
    async () => {
      if (finished) return;
      const { data } = await api.get(`/delivery/${deliveryId}`);
      setDelivery(data);
    },
    3000,
    [deliveryId, finished]
  );

  const driverLocation = useDriverLocation(delivery?.driverId ? `/delivery/${deliveryId}/driver-location` : null, !finished);

  if (!delivery) {
    return (
      <div className="center-screen">
        <span className="spinner" />
      </div>
    );
  }

  return (
    <div className="map-page">
      {driverLocation ? (
        <MapView center={driverLocation} zoom={15} marker={{ ...driverLocation, label: "Driver" }} />
      ) : (
        <div className="center-screen">
          <span className="spinner" />
          <p className="status-text">Waiting for driver's location…</p>
        </div>
      )}

      <div className="floating floating-bottom card">
        <h2 className="card-title">{STATUS_LABELS[delivery.status] ?? delivery.status}</h2>
        <p className="muted">{delivery.packageDescription}</p>
        {delivery.fare != null && <p className="fare">{formatUGX(delivery.fare)}</p>}
      </div>
    </div>
  );
}
