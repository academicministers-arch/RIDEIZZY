import { FormEvent, useCallback, useEffect, useState } from "react";
import { api, errorMessage } from "../services/api";
import { useToast } from "../context/ToastContext";

export default function AdminAgenciesPage() {
  const toast = useToast();
  const [agencies, setAgencies] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(() => {
    return api
      .get("/admin/agencies")
      .then(({ data }) => setAgencies(data))
      .catch((err) => toast(errorMessage(err), "error"))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleInvite(e: FormEvent) {
    e.preventDefault();
    if (!name) return;
    setSubmitting(true);
    try {
      const { data } = await api.post("/admin/agencies", { name, contact_email: email || undefined });
      setName("");
      setEmail("");
      toast(`Invite code ${data.invite_code} created. Send it to the agency: they enter it when they sign up.`, "success");
      await load();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="page">
      <h1 className="title">Travel Agencies</h1>

      <form className="card form invite-form" onSubmit={handleInvite}>
        <div className="grid-2">
          <div>
            <label className="label">Agency name</label>
            <input className="input" required value={name} onChange={(e) => setName(e.target.value)} placeholder="Agency name" />
          </div>
          <div>
            <label className="label">Contact email (optional, for your records)</label>
            <input
              className="input"
              type="email"
              autoCapitalize="none"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@agency.com"
            />
          </div>
        </div>
        <button className="btn btn-primary mt-sm" type="submit" disabled={submitting}>
          {submitting ? "Creating…" : "Create invite code"}
        </button>
      </form>

      {loading && <span className="spinner" />}
      {!loading && agencies.length === 0 && <p className="empty">No agency invites yet.</p>}

      <div className="stack">
        {agencies.map((item) => (
          <div key={item.agency_id} className="card">
            <div className="card-title">{item.name}</div>
            {item.contactEmail && <p className="muted">{item.contactEmail}</p>}
            {item.inviteCode && (
              <p className="muted">
                Invite code: <strong style={{ letterSpacing: "0.08em" }}>{item.inviteCode}</strong>
              </p>
            )}
            <span className={`badge ${item.status === "active" ? "badge-active" : "badge-invited"}`}>{item.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
