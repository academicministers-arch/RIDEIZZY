import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import MapView from "../components/MapView";
import { api } from "../services/api";
import { usePolling, useDriverLocation } from "../hooks";
import { formatUGX } from "../utils/currency";

// Ride status comes from polling the API (it changes rarely: searching ->
// accepted -> in_progress -> completed). Driver location, which changes
// constantly, is polled separately from its own endpoint.
export default function FindingDriverPage() {
  const { rideId } = useParams();
  const [ride, setRide] = useState<any>(null);

  const finished = ride?.status === "completed" || ride?.status === "cancelled";
  usePolling(
    async () => {
      if (finished) return;
      const { data } = await api.get(`/rides/${rideId}`);
      setRide(data);
    },
    3000,
    [rideId, finished]
  );

  const tracking = ride?.status === "accepted" || ride?.status === "in_progress";
  const driverLocation = useDriverLocation(ride?.driverId ? `/rides/${rideId}/driver-location` : null, tracking);

  if (!ride || ride.status === "searching") {
    return (
      <div className="center-screen">
        <span className="spinner" />
        <p className="status-text">Finding you a driver…</p>
      </div>
    );
  }

  if (tracking) {
    return (
      <div className="map-page">
        {driverLocation ? (
          <MapView center={driverLocation} zoom={15} marker={{ ...driverLocation, label: "Your driver" }} />
        ) : (
          <div className="center-screen">
            <span className="spinner" />
            <p className="status-text">Waiting for driver's location…</p>
          </div>
        )}
        <div className="floating floating-bottom card">
          <h2 className="card-title">Driver is on the way</h2>
          <p className="muted">Status: {ride.status}</p>
        </div>
      </div>
    );
  }

  if (ride.status === "completed") {
    return (
      <div className="center-screen">
        <h1 className="title">Trip complete</h1>
        <p className="status-text">Fare: {formatUGX(ride.fare)}</p>
        <Link to="/rides" className="btn btn-primary mt-lg">Back to rides</Link>
      </div>
    );
  }

  return (
    <div className="center-screen">
      <h1 className="title">Ride {ride.status}</h1>
      <Link to="/rides" className="btn btn-primary mt-lg">Back to rides</Link>
    </div>
  );
}
