import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api, errorMessage } from "../services/api";
import { usePolling } from "../hooks";
import { useToast } from "../context/ToastContext";
import { formatMoney } from "../utils/currency";

const STATUS_LABELS: Record<string, string> = {
  pending: "Waiting for a quote from our travel partner",
  quoted: "An agent has quoted this - awaiting admin approval",
  quote_approved: "Quote approved - review below",
  confirmed: "Booking confirmed",
  ticketed: "Ticket issued",
};

export default function FlightRequestStatusPage() {
  const { requestId } = useParams();
  const toast = useToast();
  const [request, setRequest] = useState<any>(null);
  const [deciding, setDeciding] = useState(false);
  const [loaded, setLoaded] = useState(false);

  async function load() {
    const { data } = await api.get("/travel/requests/me");
    setRequest(data.find((r: any) => r.request_id === requestId) ?? null);
    setLoaded(true);
  }

  usePolling(load, 4000, [requestId]);

  async function handleDecision(quoteId: string, decision: "accept" | "decline") {
    setDeciding(true);
    try {
      await api.post(`/travel/quotes/${quoteId}/decision`, { decision });
      toast(decision === "accept" ? "Quote accepted." : "Quote declined.", "success");
      await load();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setDeciding(false);
    }
  }

  if (!request) {
    return (
      <div className="page">
        {loaded ? <p className="empty">We couldn't find that flight request.</p> : <span className="spinner" />}
        <Link to="/travel" className="btn btn-ghost mt-lg">Back</Link>
      </div>
    );
  }

  return (
    <div className="page">
      <h1 className="title">
        {request.origin} → {request.destination}
      </h1>
      <p className="subtitle">{STATUS_LABELS[request.status] ?? request.status}</p>

      {request.status === "quote_approved" && request.quote && (
        <div className="card">
          <div className="price">{formatMoney(request.quote.price, request.quote.currency)}</div>
          <p className="itinerary">{request.quote.itinerary}</p>
          <div className="grid-2 mt-lg">
            <button className="btn btn-primary" disabled={deciding} onClick={() => handleDecision(request.quote.quote_id, "accept")}>
              Accept
            </button>
            <button className="btn btn-outline" disabled={deciding} onClick={() => handleDecision(request.quote.quote_id, "decline")}>
              Decline
            </button>
          </div>
        </div>
      )}

      <Link to="/travel" className="btn btn-ghost mt-lg">New request</Link>
    </div>
  );
}
