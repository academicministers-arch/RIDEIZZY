import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import MapView, { MapPoint } from "../components/MapView";

const KAMPALA_FALLBACK: MapPoint = { lat: 0.3476, lng: 32.5825 };

export default function RidesHomePage() {
  const [center, setCenter] = useState<MapPoint>(KAMPALA_FALLBACK);
  const [located, setLocated] = useState(false);

  useEffect(() => {
    if (!("geolocation" in navigator)) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCenter({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocated(true);
      },
      () => {
        /* permission denied or unavailable: stay on the Kampala fallback */
      },
      { timeout: 8000 }
    );
  }, []);

  return (
    <div className="map-page">
      <MapView center={center} zoom={located ? 15 : 13} marker={{ ...center, label: located ? "You are here" : "Kampala" }} />

      <Link to="/rides/request" className="floating floating-top search-bar">
        <span className="search-icon" aria-hidden>🔍</span> Where to?
      </Link>

      <Link to="/delivery/request" className="floating floating-bottom btn btn-primary btn-block">
        📦 Send a Package or Book a Truck
      </Link>
    </div>
  );
}
