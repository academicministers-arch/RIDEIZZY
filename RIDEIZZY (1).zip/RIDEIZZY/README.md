# RIDEIZZY
PLAN YOUR TRIPS

- `rideizzy-web/rideizzy-web`: React + Vite web app
- `rideizzy-api`: Express API on **Turso**, with email + password accounts

Start the API first (see `rideizzy-api/README.md`), then the web app (see its README).
