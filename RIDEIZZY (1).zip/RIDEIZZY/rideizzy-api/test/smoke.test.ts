import assert from "node:assert/strict";
import { rmSync } from "node:fs";
import type { AddressInfo } from "node:net";
import { after, before, describe, it } from "node:test";

const DB_FILE = "/tmp/rideizzy-smoke.db";
rmSync(DB_FILE, { force: true });
process.env.TURSO_DATABASE_URL = `file:${DB_FILE}`;
process.env.SESSION_SECRET = "x".repeat(40);
process.env.ALLOWED_ORIGINS = "http://localhost:5173";
process.env.AUTH_RATE_LIMIT = "1000";

const { createApp } = await import("../src/app.js");
const { migrate, db } = await import("../src/db.js");
const { issueSession } = await import("../src/auth.js");

let base = "";
let server: ReturnType<ReturnType<typeof createApp>["listen"]>;

// Test helper: inserts a user directly (skips the slow password hash) and mints a session for them.
async function makeUser(email: string, opts: { admin?: boolean } = {}) {
  const uid = crypto.randomUUID();
  await db.execute({
    sql: "INSERT INTO users (uid, email, name, password_hash, is_admin) VALUES (?,?,?,?,?)",
    args: [uid, email, email.split("@")[0], "x", opts.admin ? 1 : 0],
  });
  return { uid, token: await issueSession(uid) };
}

async function call(token: string | null, method: string, path: string, body?: unknown) {
  const res = await fetch(base + path, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  return { status: res.status, data: text ? JSON.parse(text) : null };
}

const A = { lat: 0.3476, lng: 32.5825, address: "Kampala" };
const B = { lat: 0.3136, lng: 32.5811, address: "Entebbe Rd" };

before(async () => {
  await migrate();
  server = createApp().listen(0);
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
after(() => server.close());

describe("auth", () => {
  it("rejects missing and forged session tokens", async () => {
    assert.equal((await call(null, "GET", "/auth/me")).status, 401);
    assert.equal((await call("not.a.jwt", "GET", "/auth/me")).status, 401);
  });

  it("sign up, then sign in, with validation", async () => {
    const good = { name: "Amina K", email: "Amina@Example.com", password: "correct horse 9" };
    assert.equal((await call(null, "POST", "/auth/register", { ...good, password: "short" })).status, 400);
    assert.equal((await call(null, "POST", "/auth/register", { ...good, email: "not-an-email" })).status, 400);
    assert.equal((await call(null, "POST", "/auth/register", { ...good, name: "  " })).status, 400);

    const reg = await call(null, "POST", "/auth/register", good);
    assert.equal(reg.status, 201);
    assert.ok(reg.data.token);
    assert.equal(reg.data.profile, null); // must still pick a role
    assert.equal(reg.data.user.email, "amina@example.com");

    // duplicate email, in any letter case
    assert.equal((await call(null, "POST", "/auth/register", { ...good, email: "AMINA@example.com" })).status, 409);

    const login = await call(null, "POST", "/auth/login", { email: "amina@example.com", password: good.password });
    assert.equal(login.status, 200);
    const me = await call(login.data.token, "GET", "/auth/me");
    assert.equal(me.data.user.name, "Amina K");

    const bad = await call(null, "POST", "/auth/login", { email: "amina@example.com", password: "wrong password" });
    assert.equal(bad.status, 401);
    const unknown = await call(null, "POST", "/auth/login", { email: "nobody@example.com", password: "whatever123" });
    assert.equal(unknown.status, 401);
    assert.equal(bad.data.detail, unknown.data.detail); // same message: doesn't reveal which emails exist
  });

  it("passwords are stored hashed, never as plain text", async () => {
    const r = await db.execute({ sql: "SELECT password_hash FROM users WHERE email=?", args: ["amina@example.com"] });
    const stored = String(r.rows[0][0]);
    assert.ok(stored.startsWith("scrypt$"));
    assert.ok(!stored.includes("correct horse"));
  });

  it("locks out repeated wrong passwords", async () => {
    await call(null, "POST", "/auth/register", { name: "Lock Me", email: "lock@example.com", password: "right-password-1" });
    let last = 0;
    for (let i = 0; i < 9; i++) {
      last = (await call(null, "POST", "/auth/login", { email: "lock@example.com", password: `wrong-${i}-pass` })).status;
    }
    assert.equal(last, 429);
    // even the right password is refused while locked
    assert.equal((await call(null, "POST", "/auth/login", { email: "lock@example.com", password: "right-password-1" })).status, 429);
  });

  it("can pick safe roles but not admin/agent, and signing up with any email never grants privileges", async () => {
    const u = await makeUser("rider1@example.com");
    assert.equal((await call(u.token, "GET", "/auth/me")).data.profile, null);
    assert.equal((await call(u.token, "POST", "/users/profile", { roles: ["admin"] })).status, 400);
    assert.equal((await call(u.token, "POST", "/users/profile", { roles: ["agent"] })).status, 400);
    const r = await call(u.token, "POST", "/users/profile", { roles: ["rider"] });
    assert.deepEqual(r.data.profile.roles, ["rider"]);

    const sneaky = await call(null, "POST", "/auth/register", { name: "Sneaky", email: "admin@example.com", password: "password-1234" });
    assert.equal(sneaky.data.profile, null);
    assert.equal((await call(sneaky.data.token, "GET", "/travel/admin/quotes/pending")).status, 403);
  });

  it("admin flag gives admin role and a profile", async () => {
    const a = await makeUser("boss@example.com", { admin: true });
    const me = await call(a.token, "GET", "/auth/me");
    assert.ok(me.data.profile.roles.includes("admin"));
  });
});

describe("rides, deliveries, driver location", () => {
  it("full rider flow with ownership checks", async () => {
    const rider = await makeUser("r2@example.com");
    const other = await makeUser("r3@example.com");
    const driver = await makeUser("d1@example.com");
    for (const u of [rider, other]) await call(u.token, "POST", "/users/profile", { roles: ["rider"] });
    await call(driver.token, "POST", "/users/profile", { roles: ["driver"] });

    const est = await call(rider.token, "POST", "/rides/estimate", { pickup: A, dropoff: B });
    assert.equal(est.status, 200);
    assert.ok(est.data.estimates.economy >= 5000);

    // Client-sent fare is ignored; server computes it.
    const req = await call(rider.token, "POST", "/rides/request", { pickup: A, dropoff: B, vehicle_class: "economy", estimated_fare: 1 });
    assert.equal(req.status, 201);
    const ride = await call(rider.token, "GET", `/rides/${req.data.ride_id}`);
    assert.equal(ride.data.status, "searching");
    assert.equal(ride.data.fare, est.data.estimates.economy);

    assert.equal((await call(other.token, "GET", `/rides/${req.data.ride_id}`)).status, 404);
    assert.equal((await call(rider.token, "POST", "/rides/request", { pickup: A, dropoff: B, vehicle_class: "delivery_motorbike" })).status, 400);

    assert.equal((await call(rider.token, "GET", `/rides/${req.data.ride_id}/driver-location`)).data, null);
    assert.equal((await call(rider.token, "PUT", "/drivers/location", { lat: 1, lng: 1 })).status, 403);
    await db.execute({ sql: "UPDATE rides SET driver_id=?, status='accepted' WHERE ride_id=?", args: [driver.uid, req.data.ride_id] });
    assert.equal((await call(driver.token, "PUT", "/drivers/location", { lat: 0.33, lng: 32.58, heading: 90 })).status, 204);
    const loc = await call(rider.token, "GET", `/rides/${req.data.ride_id}/driver-location`);
    assert.deepEqual(loc.data, { lat: 0.33, lng: 32.58, heading: 90 });
    assert.equal((await call(other.token, "GET", `/rides/${req.data.ride_id}/driver-location`)).status, 404);

    const del = await call(rider.token, "POST", "/delivery/request", {
      pickup: A, dropoff: B, vehicle_class: "delivery_motorbike", package_description: "2 boxes", recipient_name: null,
    });
    assert.equal(del.status, 201);
    const d = await call(rider.token, "GET", `/delivery/${del.data.delivery_id}`);
    assert.equal(d.data.packageDescription, "2 boxes");
    assert.equal((await call(other.token, "GET", `/delivery/${del.data.delivery_id}`)).status, 404);
  });
});

describe("flight quotes: request -> agent quote -> admin approval -> traveler decision", () => {
  it("runs the whole workflow and enforces roles", async () => {
    const rider = await makeUser("r4@example.com");
    const admin = await makeUser("admin2@example.com", { admin: true });
    const agent = await makeUser("agent@example.com");
    await call(rider.token, "POST", "/users/profile", { roles: ["rider"] });

    // Not an agent until they redeem an admin-issued invite code.
    assert.equal((await call(agent.token, "GET", "/travel/requests/queue")).status, 403);
    assert.equal((await call(rider.token, "POST", "/admin/agencies", { name: "X" })).status, 403);
    const inv = await call(admin.token, "POST", "/admin/agencies", { name: "Sky Travel", contact_email: "desk@sky.example" });
    assert.equal(inv.status, 201);
    assert.match(inv.data.invite_code, /^[A-Z2-9]{5}-[A-Z2-9]{5}$/);
    const list = await call(admin.token, "GET", "/admin/agencies");
    assert.equal(list.data[0].status, "invited");
    assert.equal(list.data[0].inviteCode, inv.data.invite_code);

    assert.equal((await call(agent.token, "POST", "/auth/redeem-invite", { code: "WRONG-CODE1" })).status, 400);
    const redeemed = await call(agent.token, "POST", "/auth/redeem-invite", { code: inv.data.invite_code.toLowerCase() });
    assert.equal(redeemed.status, 200);
    assert.ok(redeemed.data.profile.roles.includes("agent"));
    // single use
    const agent2 = await makeUser("agent2@example.com");
    assert.equal((await call(agent2.token, "POST", "/auth/redeem-invite", { code: inv.data.invite_code })).status, 400);
    const after = await call(admin.token, "GET", "/admin/agencies");
    assert.equal(after.data[0].status, "active");
    assert.equal(after.data[0].inviteCode, null);

    // A second invite can be used while signing up.
    const inv2 = await call(admin.token, "POST", "/admin/agencies", { name: "Blue Air Agents" });
    const bad = await call(null, "POST", "/auth/register", { name: "Ag Two", email: "ag2@example.com", password: "password-1234", invite_code: "NOPE-NOPE00" });
    assert.equal(bad.status, 400);
    assert.equal((await call(null, "POST", "/auth/login", { email: "ag2@example.com", password: "password-1234" })).status, 401); // sign-up was cancelled
    const good = await call(null, "POST", "/auth/register", { name: "Ag Two", email: "ag2@example.com", password: "password-1234", invite_code: inv2.data.invite_code });
    assert.equal(good.status, 201);
    assert.ok(good.data.profile.roles.includes("agent"));

    const fr = await call(rider.token, "POST", "/travel/requests", { origin: "EBB", destination: "NBO", depart_date: "2026-12-01", passengers: 2, cabin_class: "economy" });
    assert.equal(fr.status, 201);
    const rid = fr.data.request_id;

    const queue = await call(agent.token, "GET", "/travel/requests/queue");
    assert.ok(queue.data.some((r: any) => r.request_id === rid));

    const q = await call(agent.token, "POST", `/travel/requests/${rid}/quote`, { request_id: rid, price: 3200000, currency: "UGX", itinerary: "KQ 411", expires_at: "2026-11-20" });
    assert.equal(q.status, 201);
    assert.equal((await call(agent.token, "POST", `/travel/requests/${rid}/quote`, { price: 1, itinerary: "again", expires_at: "2026-11-20" })).status, 409);

    // Traveler can't see the quote yet.
    let mine = await call(rider.token, "GET", "/travel/requests/me");
    assert.equal(mine.data.find((r: any) => r.request_id === rid).quote, null);
    assert.equal((await call(rider.token, "POST", `/travel/quotes/${q.data.quote_id}/decision`, { decision: "accept" })).status, 409);

    const pending = await call(admin.token, "GET", "/travel/admin/quotes/pending");
    assert.equal(pending.data.length, 1);
    assert.equal((await call(agent.token, "POST", `/travel/admin/quotes/${q.data.quote_id}/approve`)).status, 403);
    assert.equal((await call(admin.token, "POST", `/travel/admin/quotes/${q.data.quote_id}/approve`)).status, 200);
    assert.equal((await call(admin.token, "POST", `/travel/admin/quotes/${q.data.quote_id}/approve`)).status, 409);

    mine = await call(rider.token, "GET", "/travel/requests/me");
    const item = mine.data.find((r: any) => r.request_id === rid);
    assert.equal(item.status, "quote_approved");
    assert.equal(item.quote.price, 3200000);
    const notes = await call(rider.token, "GET", "/notifications/me");
    assert.equal(notes.data[0].title, "Your flight quote is ready");

    const other = await makeUser("r5@example.com");
    await call(other.token, "POST", "/users/profile", { roles: ["rider"] });
    assert.equal((await call(other.token, "POST", `/travel/quotes/${q.data.quote_id}/decision`, { decision: "accept" })).status, 404);

    assert.equal((await call(rider.token, "POST", `/travel/quotes/${q.data.quote_id}/decision`, { decision: "accept" })).status, 200);
    mine = await call(rider.token, "GET", "/travel/requests/me");
    assert.equal(mine.data.find((r: any) => r.request_id === rid).status, "confirmed");
    assert.equal((await call(rider.token, "POST", `/travel/quotes/${q.data.quote_id}/decision`, { decision: "decline" })).status, 409);
  });
});

describe("school trips", () => {
  it("need a linked school and stay inside it", async () => {
    const s1 = await makeUser("s1@example.com");
    const s2 = await makeUser("s2@example.com");
    for (const s of [s1, s2]) await call(s.token, "POST", "/users/profile", { roles: ["school_admin"] });
    const adminTok = (await makeUser("admin3@example.com", { admin: true })).token;

    const trip = { destination: "Museum", date: "2026-11-05", passenger_count: 40, vehicle_type: "coaster", notes: "" };
    assert.equal((await call(s1.token, "POST", "/school/trips", trip)).status, 400);

    assert.equal((await call(adminTok, "POST", "/admin/users/school", { email: "s1@example.com", school_id: "school-a" })).status, 200);
    assert.equal((await call(adminTok, "POST", "/admin/users/school", { email: "s2@example.com", school_id: "school-b" })).status, 200);
    // body school_id is ignored; the profile's school wins
    assert.equal((await call(s1.token, "POST", "/school/trips", { ...trip, school_id: "school-b" })).status, 201);

    const mine = await call(s1.token, "GET", "/school/trips/school-a");
    assert.equal(mine.data.length, 1);
    assert.equal(mine.data[0].destination, "Museum");
    assert.equal((await call(s2.token, "GET", "/school/trips/school-a")).status, 403);
    assert.equal((await call(s2.token, "GET", "/school/trips/school-b")).data.length, 0);
  });
});

describe("misc", () => {
  it("CORS only echoes allowed origins; maps reports missing config", async () => {
    const ok = await fetch(base + "/health", { headers: { Origin: "http://localhost:5173" } });
    assert.equal(ok.headers.get("access-control-allow-origin"), "http://localhost:5173");
    const bad = await fetch(base + "/health", { headers: { Origin: "https://evil.example" } });
    assert.equal(bad.headers.get("access-control-allow-origin"), null);
    const u = await makeUser("m1@example.com");
    assert.equal((await call(u.token, "GET", "/maps/autocomplete?input=kampala")).status, 503);
  });
});
