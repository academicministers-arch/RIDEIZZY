# Rideizzy API

Express + TypeScript backend for the Rideizzy web app. Data lives in **Turso** (libSQL). People sign up with an
**email and password**. Tables are created automatically on startup.

## Set up

1. **Turso**
   ```bash
   turso db create rideizzy
   turso db show rideizzy --url          # -> TURSO_DATABASE_URL
   turso db tokens create rideizzy       # -> TURSO_AUTH_TOKEN
   ```
   For a quick local trial skip Turso and use `TURSO_DATABASE_URL=file:./local.db` (leave the token empty).
2. **Address search** (optional, needed for the pickup/dropoff boxes): enable **Places API (New)** in Google Cloud and
   create an API key. It is used on the server only.
3. ```bash
   npm install
   cp .env.example .env     # fill in the values; SESSION_SECRET: openssl rand -base64 48
   npm run dev              # http://localhost:8000
   ```

## How sign-in works

- `POST /auth/register` (name, email, password of 8+ characters) creates the account and signs the person in.
- `POST /auth/login` (email, password) signs in. Wrong passwords get the same message whether or not the email exists, and
  8 wrong tries from one address lock that email out for 15 minutes.
- Passwords are stored only as salted **scrypt** hashes. Sessions are signed tokens that last 7 days.

## Roles

- `rider`, `school_admin`, `driver`: chosen by the person on first sign-in.
- **`admin`** is switched on from the server, so nobody can give themselves admin through the website:
  1. Create the account in the app as normal.
  2. Run `npm run make-admin -- you@example.com` (from `rideizzy-api`, with the same `.env`).
  3. Sign out and back in. The Admin tab appears.
- **`agent`** (travel agencies): an admin opens Admin > Agencies and creates an **invite code** (like `K7M2P-9XQ4R`). The
  agency enters it when signing up, or later through the "Have an invite code?" link. Each code works once.
- A school admin needs a school before requesting trips. There's no screen for it yet, so an admin calls
  `POST /admin/users/school {"email": "...", "school_id": "..."}` (the person must have an account).

## Endpoints

`/auth/register`, `/auth/login`, `/auth/me`, `/auth/redeem-invite`, `/users/profile`, `/maps/autocomplete`,
`/maps/place-details/:id`, `/rides/estimate`, `/rides/request`, `/rides/:id`, `/rides/:id/driver-location`,
`/delivery/request`, `/delivery/:id`, `/delivery/:id/driver-location`, `PUT /drivers/location`,
`/travel/requests` (+ `/me`, `/queue`, `/:id/quote`), `/travel/quotes/:id/decision`, `/travel/admin/quotes/pending`,
`/travel/admin/quotes/:id/approve`, `/school/trips`, `/admin/agencies`, `/notifications/me`.

## Test and deploy

```bash
npm test                 # runs the real flows against a temporary local libSQL file
npm run build && npm start
```

Deploy anywhere that runs Node 20+ (Render, Railway, Fly.io...). Set the same variables as `.env`, plus `TRUST_PROXY=1`
behind a load balancer, and put the deployed web address in `ALLOWED_ORIGINS`. To make your first admin on the live
database, run `npm run make-admin -- you@example.com` with the live `TURSO_DATABASE_URL` and `TURSO_AUTH_TOKEN` set.

## Good to know

- **Upgrading from the Google-sign-in version:** accounts made with Google have no password, so the old `users` and
  `agencies` tables are replaced automatically on startup. Create your account again. Rides and other data are not touched.
- **No "forgot password" yet.** Resetting a password needs the server to send email, which isn't set up. Until then, a
  forgotten password has to be reset by hand in the database.
- **No email verification.** Anyone can sign up with any address. That's why admin and agent access never depend on an
  email address.
- **Not built yet:** matching a driver to a ride/delivery, completing trips, payments, push notifications. Until driver
  screens exist, rides stay in `searching`. Fare rates in `src/pricing.ts` are placeholders.
