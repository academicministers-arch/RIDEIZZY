// Usage: npm run make-admin -- you@example.com
// The person must have created an account first. This runs on your computer/server, so only someone with
// access to the database can make an admin: nobody can grant themselves admin through the website.
import { db } from "../src/db.js";

const email = process.argv[2]?.trim().toLowerCase();
if (!email) {
  console.error("Usage: npm run make-admin -- you@example.com");
  process.exit(1);
}
const r = await db.execute({ sql: "UPDATE users SET is_admin = 1, has_profile = 1 WHERE email = ?", args: [email] });
if (r.rowsAffected === 0) {
  console.error(`No account found for ${email}. Create the account in the app first, then run this again.`);
  process.exit(1);
}
console.log(`${email} is now an admin. Sign out and back in to see the Admin tab.`);
process.exit(0);
