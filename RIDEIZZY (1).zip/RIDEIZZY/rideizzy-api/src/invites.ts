import { randomInt } from "node:crypto";
import type { Transaction } from "@libsql/client";
import { HttpError } from "./http.js";

// 32 characters with no look-alikes (no 0/O, 1/I). 10 characters is about 50 bits: not guessable.
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function newInviteCode(): string {
  return Array.from({ length: 10 }, () => ALPHABET[randomInt(ALPHABET.length)]).join("");
}

/** What the admin sees and shares: XXXXX-XXXXX */
export const showCode = (code: string) => `${code.slice(0, 5)}-${code.slice(5)}`;

/** What we store and compare: upper-case, no dashes or spaces. */
export const normalizeCode = (input: string) => input.toUpperCase().replace(/[^A-Z0-9]/g, "");

/** Single-use: marks the invite as used and makes this user an agent. Throws 400 if the code is wrong or already used. */
export async function redeemInvite(tx: Transaction, rawCode: string, uid: string) {
  const code = normalizeCode(rawCode);
  const used = await tx.execute({
    sql: "UPDATE agencies SET status='active', redeemed_by=? WHERE invite_code=? AND status='invited'",
    args: [uid, code],
  });
  if (used.rowsAffected === 0) throw new HttpError(400, "That invite code isn't valid or has already been used.");
  const agency = await tx.execute({ sql: "SELECT agency_id FROM agencies WHERE invite_code=?", args: [code] });
  await tx.execute({
    sql: "UPDATE users SET agency_id=?, has_profile=1 WHERE uid=?",
    args: [agency.rows[0][0] as string, uid],
  });
}
