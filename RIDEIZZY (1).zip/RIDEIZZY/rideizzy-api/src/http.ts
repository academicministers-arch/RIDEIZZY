import type { NextFunction, Request, Response } from "express";
import { ZodError, type ZodTypeAny, type z } from "zod";

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

/** Validate req.body / req.query with zod; throws a 400 on bad input. */
export function parse<T extends ZodTypeAny>(schema: T, data: unknown): z.infer<T> {
  return schema.parse(data);
}

// Express 5 forwards rejected async handlers here automatically.
export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof HttpError) {
    res.status(err.status).json({ detail: err.message });
    return;
  }
  if (err instanceof ZodError) {
    const issue = err.issues[0];
    const where = issue.path.length ? `${issue.path.join(".")}: ` : "";
    res.status(400).json({ detail: `${where}${issue.message}` });
    return;
  }
  console.error(err);
  res.status(500).json({ detail: "Something went wrong on the server" });
}
