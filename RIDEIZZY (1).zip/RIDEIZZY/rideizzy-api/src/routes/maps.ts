import { Router } from "express";
import { z } from "zod";
import { requireAuth } from "../auth.js";
import { config } from "../config.js";
import { HttpError, parse } from "../http.js";

export const mapsRouter = Router();
mapsRouter.use("/maps", requireAuth);

function key() {
  if (!config.mapsKey) throw new HttpError(503, "Address search isn't configured on the server (GOOGLE_MAPS_API_KEY).");
  return config.mapsKey;
}

// Uses Google "Places API (New)". The key stays on the server.
mapsRouter.get("/maps/autocomplete", async (req, res) => {
  const { input } = parse(z.object({ input: z.string().trim().min(2).max(200) }), req.query);
  const r = await fetch("https://places.googleapis.com/v1/places:autocomplete", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Goog-Api-Key": key() },
    body: JSON.stringify({ input, includedRegionCodes: [config.placesRegion] }),
  });
  if (!r.ok) throw new HttpError(502, "Address search failed");
  const data: any = await r.json();
  res.json(
    (data.suggestions ?? [])
      .filter((s: any) => s.placePrediction)
      .map((s: any) => ({ description: s.placePrediction.text?.text ?? "", place_id: s.placePrediction.placeId }))
  );
});

mapsRouter.get("/maps/place-details/:placeId", async (req, res) => {
  const { placeId } = parse(z.object({ placeId: z.string().regex(/^[A-Za-z0-9_-]{10,300}$/, "Invalid place id") }), req.params);
  const r = await fetch(`https://places.googleapis.com/v1/places/${placeId}`, {
    headers: { "X-Goog-Api-Key": key(), "X-Goog-FieldMask": "location,formattedAddress" },
  });
  if (!r.ok) throw new HttpError(502, "Could not load that place");
  const d: any = await r.json();
  if (!d.location) throw new HttpError(404, "Place not found");
  res.json({ lat: d.location.latitude, lng: d.location.longitude, address: d.formattedAddress ?? "" });
});
