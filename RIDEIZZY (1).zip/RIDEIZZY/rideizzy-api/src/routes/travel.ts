import { randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { requireAuth, requireRole } from "../auth.js";
import { db, query, txQuery, type Row } from "../db.js";
import { HttpError, parse } from "../http.js";
import { notify, notifyAdmins } from "../notify.js";

export const travelRouter = Router();
travelRouter.use("/travel", requireAuth);

const idParam = z.object({ id: z.string().uuid() });
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use the format YYYY-MM-DD");

const requestOut = (r: Row) => ({
  request_id: r.request_id,
  origin: r.origin,
  destination: r.destination,
  depart_date: r.depart_date,
  passengers: r.passengers,
  cabin_class: r.cabin_class,
  status: r.status,
});

const quoteOut = (q: Row) => ({
  quote_id: q.quote_id,
  request_id: q.request_id,
  price: q.price,
  currency: q.currency,
  itinerary: q.itinerary,
  expires_at: q.expires_at,
  status: q.status,
});

// ---------- Traveler ----------

travelRouter.post("/travel/requests", requireRole("rider"), async (req, res) => {
  const b = parse(
    z.object({
      origin: z.string().trim().min(1).max(100),
      destination: z.string().trim().min(1).max(100),
      depart_date: isoDate,
      passengers: z.number().int().min(1).max(50),
      cabin_class: z.enum(["economy", "premium_economy", "business", "first"]).default("economy"),
    }),
    req.body
  );
  const id = randomUUID();
  await db.execute({
    sql: "INSERT INTO travel_requests (request_id, rider_id, origin, destination, depart_date, passengers, cabin_class) VALUES (?,?,?,?,?,?,?)",
    args: [id, req.user!.uid, b.origin, b.destination, b.depart_date, b.passengers, b.cabin_class],
  });
  res.status(201).json({ request_id: id });
});

travelRouter.get("/travel/requests/me", requireRole("rider"), async (req, res) => {
  const requests = await query("SELECT * FROM travel_requests WHERE rider_id = ? ORDER BY created_at DESC LIMIT 100", [req.user!.uid]);
  if (requests.length === 0) return void res.json([]);
  const marks = requests.map(() => "?").join(",");
  const quotes = await query(
    `SELECT * FROM travel_quotes WHERE request_id IN (${marks}) AND status != 'pending_approval' ORDER BY created_at DESC`,
    requests.map((r) => r.request_id)
  );
  // Travelers only ever see quotes an admin has already approved.
  const latest = new Map<string, Row>();
  for (const q of quotes) if (!latest.has(q.request_id)) latest.set(q.request_id, q);
  res.json(requests.map((r) => ({ ...requestOut(r), quote: latest.has(r.request_id) ? quoteOut(latest.get(r.request_id)!) : null })));
});

travelRouter.post("/travel/quotes/:id/decision", requireRole("rider"), async (req, res) => {
  const { id } = parse(idParam, req.params);
  const { decision } = parse(z.object({ decision: z.enum(["accept", "decline"]) }), req.body);

  const tx = await db.transaction("write");
  try {
    const [q] = await txQuery(
      tx,
      `SELECT q.*, r.rider_id, r.origin, r.destination FROM travel_quotes q
         JOIN travel_requests r ON r.request_id = q.request_id WHERE q.quote_id = ?`,
      [id]
    );
    if (!q || q.rider_id !== req.user!.uid) throw new HttpError(404, "Quote not found");
    if (q.status !== "approved") throw new HttpError(409, "This quote can no longer be answered");

    if (decision === "accept") {
      await tx.execute({ sql: "UPDATE travel_quotes SET status='accepted' WHERE quote_id=?", args: [id] });
      await tx.execute({ sql: "UPDATE travel_requests SET status='confirmed' WHERE request_id=?", args: [q.request_id] });
    } else {
      // Declined: put the request back in the agents' queue so a new quote can be made.
      await tx.execute({ sql: "UPDATE travel_quotes SET status='declined' WHERE quote_id=?", args: [id] });
      await tx.execute({ sql: "UPDATE travel_requests SET status='pending' WHERE request_id=?", args: [q.request_id] });
    }
    await tx.commit();
    if (decision === "accept") await notifyAdmins("Quote accepted", `${q.origin} → ${q.destination} was accepted by the traveler.`);
    res.json({ ok: true });
  } finally {
    tx.close();
  }
});

// ---------- Agent ----------

travelRouter.get("/travel/requests/queue", requireRole("agent"), async (_req, res) => {
  const rows = await query("SELECT * FROM travel_requests WHERE status = 'pending' ORDER BY created_at ASC LIMIT 200");
  res.json(rows.map(requestOut));
});

travelRouter.post("/travel/requests/:id/quote", requireRole("agent"), async (req, res) => {
  const { id } = parse(idParam, req.params);
  const b = parse(
    z.object({
      price: z.number().positive().max(1e12),
      currency: z.string().regex(/^[A-Z]{3}$/).default("UGX"),
      itinerary: z.string().trim().min(1).max(4000),
      expires_at: isoDate,
    }),
    req.body
  );
  const quoteId = randomUUID();
  const tx = await db.transaction("write");
  try {
    // Only a request still waiting for a quote can receive one (guards against two agents racing).
    const moved = await tx.execute({ sql: "UPDATE travel_requests SET status='quoted' WHERE request_id=? AND status='pending'", args: [id] });
    if (moved.rowsAffected === 0) throw new HttpError(409, "This request is no longer waiting for a quote");
    await tx.execute({
      sql: `INSERT INTO travel_quotes (quote_id, request_id, agency_id, agent_id, price, currency, itinerary, expires_at)
            VALUES (?,?,?,?,?,?,?,?)`,
      args: [quoteId, id, req.user!.agencyId!, req.user!.uid, b.price, b.currency, b.itinerary, b.expires_at],
    });
    await tx.commit();
  } finally {
    tx.close();
  }
  await notifyAdmins("New flight quote to approve", "A travel agent submitted a quote waiting for your approval.");
  res.status(201).json({ quote_id: quoteId });
});

// ---------- Admin ----------

travelRouter.get("/travel/admin/quotes/pending", requireRole("admin"), async (_req, res) => {
  const rows = await query(
    `SELECT q.*, r.origin, r.destination, r.depart_date, r.passengers
       FROM travel_quotes q JOIN travel_requests r ON r.request_id = q.request_id
      WHERE q.status = 'pending_approval' ORDER BY q.created_at ASC LIMIT 200`
  );
  res.json(rows.map((q) => ({ ...quoteOut(q), origin: q.origin, destination: q.destination, depart_date: q.depart_date, passengers: q.passengers })));
});

travelRouter.post("/travel/admin/quotes/:id/approve", requireRole("admin"), async (req, res) => {
  const { id } = parse(idParam, req.params);
  const tx = await db.transaction("write");
  let riderId: string;
  let route: string;
  try {
    const [q] = await txQuery(
      tx,
      `SELECT q.quote_id, q.request_id, r.rider_id, r.origin, r.destination FROM travel_quotes q
         JOIN travel_requests r ON r.request_id = q.request_id WHERE q.quote_id = ?`,
      [id]
    );
    if (!q) throw new HttpError(404, "Quote not found");
    const moved = await tx.execute({ sql: "UPDATE travel_quotes SET status='approved' WHERE quote_id=? AND status='pending_approval'", args: [id] });
    if (moved.rowsAffected === 0) throw new HttpError(409, "This quote was already handled");
    await tx.execute({ sql: "UPDATE travel_requests SET status='quote_approved' WHERE request_id=?", args: [q.request_id] });
    await tx.commit();
    riderId = q.rider_id;
    route = `${q.origin} → ${q.destination}`;
  } finally {
    tx.close();
  }
  await notify(riderId, "Your flight quote is ready", `${route}: open the request to review and accept it.`);
  res.json({ ok: true });
});

