import { randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { requireAuth, requireRole } from "../auth.js";
import { db, query, queryOne } from "../db.js";
import { HttpError, parse } from "../http.js";
import { newInviteCode, showCode } from "../invites.js";

export const miscRouter = Router();
miscRouter.use(["/school", "/admin", "/notifications"], requireAuth);

// ---------- School trips ----------

miscRouter.post("/school/trips", requireRole("school_admin"), async (req, res) => {
  const b = parse(
    z.object({
      destination: z.string().trim().min(1).max(200),
      date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use the format YYYY-MM-DD"),
      passenger_count: z.number().int().min(1).max(500),
      vehicle_type: z.enum(["coaster", "bus"]),
      notes: z.string().trim().max(1000).nullish(),
    }),
    req.body
  );
  // The school comes from the signed-in user's own profile, never from the request body.
  const schoolId = req.user!.schoolId;
  if (!schoolId) throw new HttpError(400, "Your account isn't linked to a school yet. Ask an admin to set your school.");
  const id = randomUUID();
  await db.execute({
    sql: "INSERT INTO school_trips (trip_id, school_id, requested_by, destination, date, passenger_count, vehicle_type, notes) VALUES (?,?,?,?,?,?,?,?)",
    args: [id, schoolId, req.user!.uid, b.destination, b.date, b.passenger_count, b.vehicle_type, b.notes || null],
  });
  res.status(201).json({ trip_id: id });
});

miscRouter.get("/school/trips/:schoolId", requireRole("school_admin", "admin"), async (req, res) => {
  const { schoolId } = parse(z.object({ schoolId: z.string().min(1).max(100) }), req.params);
  if (!req.user!.roles.includes("admin") && req.user!.schoolId !== schoolId) throw new HttpError(403, "You don't have access to this school");
  const rows = await query("SELECT * FROM school_trips WHERE school_id = ? ORDER BY date DESC LIMIT 200", [schoolId]);
  res.json(rows.map(({ requested_by: _r, created_at: _c, ...t }) => t));
});

// ---------- Admin ----------

miscRouter.get("/admin/agencies", requireRole("admin"), async (_req, res) => {
  const rows = await query("SELECT * FROM agencies ORDER BY created_at DESC LIMIT 200");
  res.json(
    rows.map((a) => ({
      agency_id: a.agency_id,
      name: a.name,
      contactEmail: a.contact_email,
      status: a.status,
      // The code is only shown while it is still unused.
      inviteCode: a.status === "invited" ? showCode(a.invite_code) : null,
    }))
  );
});

// Creates a one-time invite code. Give it to the agency's staff; they enter it when they sign up.
miscRouter.post("/admin/agencies", requireRole("admin"), async (req, res) => {
  const b = parse(
    z.object({ name: z.string().trim().min(1).max(100), contact_email: z.string().trim().toLowerCase().email().max(200).optional() }),
    req.body
  );
  const id = randomUUID();
  const code = newInviteCode();
  await db.execute({
    sql: "INSERT INTO agencies (agency_id, name, contact_email, invite_code) VALUES (?,?,?,?)",
    args: [id, b.name, b.contact_email ?? "", code],
  });
  res.status(201).json({ agency_id: id, invite_code: showCode(code) });
});

// Link a school admin's account to a school (there's no UI for this yet).
miscRouter.post("/admin/users/school", requireRole("admin"), async (req, res) => {
  const b = parse(z.object({ email: z.string().trim().toLowerCase().email(), school_id: z.string().trim().min(1).max(100) }), req.body);
  const r = await db.execute({ sql: "UPDATE users SET school_id = ? WHERE email = ?", args: [b.school_id, b.email] });
  if (r.rowsAffected === 0) throw new HttpError(404, "No user has signed in with that email yet");
  res.json({ ok: true });
});

// ---------- Notifications ----------

miscRouter.get("/notifications/me", async (req, res) => {
  const rows = await query("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100", [req.user!.uid]);
  res.json(rows.map((n) => ({ notification_id: n.notification_id, title: n.title, body: n.body, read: n.read === 1, createdAt: n.created_at })));
});
