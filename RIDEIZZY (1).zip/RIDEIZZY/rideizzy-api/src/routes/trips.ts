import { randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { requireAuth, requireRole } from "../auth.js";
import { db, queryOne, type Row } from "../db.js";
import { HttpError, parse } from "../http.js";
import { DELIVERY_CLASSES, RIDE_CLASSES, estimate } from "../pricing.js";

export const tripsRouter = Router();
tripsRouter.use(["/rides", "/delivery", "/drivers"], requireAuth);

const place = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  address: z.string().max(300).default(""),
});

const idParam = z.object({ id: z.string().uuid() });

function placeOut(row: Row, p: "pickup" | "dropoff") {
  return { lat: row[`${p}_lat`], lng: row[`${p}_lng`], address: row[`${p}_address`] };
}

function rideOut(r: Row) {
  return {
    ride_id: r.ride_id,
    status: r.status,
    driverId: r.driver_id,
    vehicleClass: r.vehicle_class,
    estimatedFare: r.estimated_fare,
    fare: r.fare ?? r.estimated_fare,
    pickup: placeOut(r, "pickup"),
    dropoff: placeOut(r, "dropoff"),
    createdAt: r.created_at,
  };
}

function deliveryOut(d: Row) {
  return {
    delivery_id: d.delivery_id,
    status: d.status,
    driverId: d.driver_id,
    vehicleClass: d.vehicle_class,
    packageDescription: d.package_description,
    recipientName: d.recipient_name,
    recipientPhone: d.recipient_phone,
    estimatedFare: d.estimated_fare,
    fare: d.fare ?? d.estimated_fare,
    pickup: placeOut(d, "pickup"),
    dropoff: placeOut(d, "dropoff"),
    createdAt: d.created_at,
  };
}

async function driverLocation(driverId: string | null) {
  if (!driverId) return null;
  const l = await queryOne("SELECT lat, lng, heading FROM driver_locations WHERE driver_id = ?", [driverId]);
  return l ? { lat: l.lat, lng: l.lng, heading: l.heading } : null;
}

// ---------- Fare estimate (rides and deliveries) ----------

tripsRouter.post("/rides/estimate", async (req, res) => {
  const { pickup, dropoff } = parse(z.object({ pickup: place, dropoff: place }), req.body);
  res.json(estimate(pickup, dropoff));
});

// ---------- Rides ----------

tripsRouter.post("/rides/request", requireRole("rider"), async (req, res) => {
  const b = parse(
    z.object({ pickup: place, dropoff: place, vehicle_class: z.enum(RIDE_CLASSES) }),
    req.body
  );
  // The fare is computed here; the client's estimated_fare is ignored.
  const fare = estimate(b.pickup, b.dropoff).estimates[b.vehicle_class];
  const id = randomUUID();
  await db.execute({
    sql: `INSERT INTO rides (ride_id, rider_id, pickup_lat, pickup_lng, pickup_address,
                             dropoff_lat, dropoff_lng, dropoff_address, vehicle_class, estimated_fare)
          VALUES (?,?,?,?,?,?,?,?,?,?)`,
    args: [id, req.user!.uid, b.pickup.lat, b.pickup.lng, b.pickup.address, b.dropoff.lat, b.dropoff.lng, b.dropoff.address, b.vehicle_class, fare],
  });
  res.status(201).json({ ride_id: id });
});

async function ownRide(id: string, uid: string) {
  const r = await queryOne("SELECT * FROM rides WHERE ride_id = ? AND rider_id = ?", [id, uid]);
  if (!r) throw new HttpError(404, "Ride not found");
  return r;
}

tripsRouter.get("/rides/:id", async (req, res) => {
  const { id } = parse(idParam, req.params);
  res.json(rideOut(await ownRide(id, req.user!.uid)));
});

tripsRouter.get("/rides/:id/driver-location", async (req, res) => {
  const { id } = parse(idParam, req.params);
  const ride = await ownRide(id, req.user!.uid);
  res.json(await driverLocation(ride.driver_id));
});

// ---------- Deliveries ----------

tripsRouter.post("/delivery/request", requireRole("rider"), async (req, res) => {
  const b = parse(
    z.object({
      pickup: place,
      dropoff: place,
      vehicle_class: z.enum(DELIVERY_CLASSES),
      package_description: z.string().trim().min(1).max(500),
      recipient_name: z.string().trim().max(100).nullish(),
      recipient_phone: z.string().trim().max(30).nullish(),
    }),
    req.body
  );
  const fare = estimate(b.pickup, b.dropoff).estimates[b.vehicle_class];
  const id = randomUUID();
  await db.execute({
    sql: `INSERT INTO deliveries (delivery_id, requester_id, pickup_lat, pickup_lng, pickup_address,
                                  dropoff_lat, dropoff_lng, dropoff_address, vehicle_class,
                                  package_description, recipient_name, recipient_phone, estimated_fare)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    args: [
      id, req.user!.uid, b.pickup.lat, b.pickup.lng, b.pickup.address, b.dropoff.lat, b.dropoff.lng, b.dropoff.address,
      b.vehicle_class, b.package_description, b.recipient_name || null, b.recipient_phone || null, fare,
    ],
  });
  res.status(201).json({ delivery_id: id });
});

async function ownDelivery(id: string, uid: string) {
  const d = await queryOne("SELECT * FROM deliveries WHERE delivery_id = ? AND requester_id = ?", [id, uid]);
  if (!d) throw new HttpError(404, "Delivery not found");
  return d;
}

tripsRouter.get("/delivery/:id", async (req, res) => {
  const { id } = parse(idParam, req.params);
  res.json(deliveryOut(await ownDelivery(id, req.user!.uid)));
});

tripsRouter.get("/delivery/:id/driver-location", async (req, res) => {
  const { id } = parse(idParam, req.params);
  const d = await ownDelivery(id, req.user!.uid);
  res.json(await driverLocation(d.driver_id));
});

// ---------- Driver pushes their own position (replaces Realtime Database writes) ----------

tripsRouter.put("/drivers/location", requireRole("driver"), async (req, res) => {
  const b = parse(
    z.object({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180), heading: z.number().min(0).max(360).nullish() }),
    req.body
  );
  await db.execute({
    sql: `INSERT INTO driver_locations (driver_id, lat, lng, heading, updated_at) VALUES (?,?,?,?,?)
          ON CONFLICT(driver_id) DO UPDATE SET lat=excluded.lat, lng=excluded.lng, heading=excluded.heading, updated_at=excluded.updated_at`,
    args: [req.user!.uid, b.lat, b.lng, b.heading ?? null, new Date().toISOString()],
  });
  res.status(204).end();
});
