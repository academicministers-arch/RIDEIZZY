import { randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { SELF_SERVE_ROLES, issueSession, loadUser, profileOf, requireAuth, type AppUser } from "../auth.js";
import { db, queryOne } from "../db.js";
import { HttpError, parse } from "../http.js";
import { redeemInvite } from "../invites.js";
import { clearFailures, isLocked, recordFailure } from "../loginGuard.js";
import { dummyHash, hashPassword, verifyPassword } from "../password.js";

export const authRouter = Router();

function payload(u: AppUser) {
  return { user: { name: u.name, email: u.email }, profile: u.hasProfile ? profileOf(u) : null };
}

const email = z.string().trim().toLowerCase().email("Enter a valid email address").max(200);

// ---------- Create an account ----------

authRouter.post("/auth/register", async (req, res) => {
  const b = parse(
    z.object({
      name: z.string().trim().min(1, "Enter your name").max(100),
      email,
      password: z.string().min(8, "Password must be at least 8 characters").max(128, "Password is too long"),
      invite_code: z.string().trim().max(40).optional(),
    }),
    req.body
  );

  if (await queryOne("SELECT 1 AS x FROM users WHERE email = ?", [b.email])) {
    throw new HttpError(409, "An account with this email already exists. Try signing in instead.");
  }

  const uid = randomUUID();
  const hash = await hashPassword(b.password);
  const tx = await db.transaction("write");
  try {
    await tx.execute({ sql: "INSERT INTO users (uid, email, name, password_hash) VALUES (?,?,?,?)", args: [uid, b.email, b.name, hash] });
    // A valid agency invite code turns this account into an agent. A bad one cancels the whole sign-up.
    if (b.invite_code) await redeemInvite(tx, b.invite_code, uid);
    await tx.commit();
  } catch (err: any) {
    if (String(err?.message ?? "").includes("UNIQUE") && String(err.message).includes("users.email")) {
      throw new HttpError(409, "An account with this email already exists. Try signing in instead.");
    }
    throw err;
  } finally {
    tx.close();
  }

  const user = (await loadUser(uid))!;
  res.status(201).json({ token: await issueSession(uid), ...payload(user) });
});

// ---------- Sign in ----------

authRouter.post("/auth/login", async (req, res) => {
  const b = parse(z.object({ email, password: z.string().min(1).max(128) }), req.body);
  const guardKey = `${req.ip}|${b.email}`;
  if (isLocked(guardKey)) throw new HttpError(429, "Too many failed attempts. Please wait a few minutes and try again.");

  const row = await queryOne("SELECT uid, password_hash FROM users WHERE email = ?", [b.email]);
  const ok = await verifyPassword(b.password, row?.password_hash ?? (await dummyHash()));
  if (!row || !ok) {
    recordFailure(guardKey);
    throw new HttpError(401, "Incorrect email or password.");
  }
  clearFailures(guardKey);

  const user = (await loadUser(row.uid))!;
  res.json({ token: await issueSession(row.uid), ...payload(user) });
});

authRouter.get("/auth/me", requireAuth, (req, res) => {
  res.json(payload(req.user!));
});

// ---------- Roles ----------

// First-time role selection. Only non-privileged roles can be self-selected.
authRouter.post("/users/profile", requireAuth, async (req, res) => {
  const { roles } = parse(z.object({ roles: z.array(z.enum(SELF_SERVE_ROLES)).min(1) }), req.body);
  const unique = [...new Set(roles)];
  await db.execute({ sql: "UPDATE users SET roles = ?, has_profile = 1 WHERE uid = ?", args: [JSON.stringify(unique), req.user!.uid] });
  res.json(payload((await loadUser(req.user!.uid))!));
});

// Travel-agency staff enter the one-time code an admin gave them.
authRouter.post("/auth/redeem-invite", requireAuth, async (req, res) => {
  const { code } = parse(z.object({ code: z.string().trim().min(4).max(40) }), req.body);
  if (req.user!.agencyId) throw new HttpError(409, "Your account already has agency access.");
  const tx = await db.transaction("write");
  try {
    await redeemInvite(tx, code, req.user!.uid);
    await tx.commit();
  } finally {
    tx.close();
  }
  res.json(payload((await loadUser(req.user!.uid))!));
});
