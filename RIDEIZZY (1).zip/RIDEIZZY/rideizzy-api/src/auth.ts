import type { NextFunction, Request, Response } from "express";
import { SignJWT, jwtVerify } from "jose";
import { config } from "./config.js";
import { queryOne, type Row } from "./db.js";
import { HttpError } from "./http.js";

export type Role = "rider" | "driver" | "parent" | "school_admin" | "agent" | "admin";
export const SELF_SERVE_ROLES = ["rider", "school_admin", "driver"] as const;

export interface AppUser {
  uid: string;
  email: string;
  name: string;
  roles: Role[];
  schoolId: string | null;
  agencyId: string | null;
  hasProfile: boolean;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AppUser;
    }
  }
}

// ---------- Our own session token ----------

const secret = new TextEncoder().encode(config.sessionSecret);
const ISSUER = "rideizzy-api";

export function issueSession(uid: string): Promise<string> {
  return new SignJWT({})
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(uid)
    .setIssuer(ISSUER)
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret);
}

async function uidFromToken(token: string): Promise<string> {
  const { payload } = await jwtVerify(token, secret, { issuer: ISSUER, algorithms: ["HS256"] });
  if (!payload.sub) throw new Error("no subject");
  return payload.sub;
}

// ---------- Users & roles ----------

/**
 * Admin and agent are never self-selected. Admin is switched on from the server (`npm run make-admin`);
 * agent comes from redeeming an invite code an admin created.
 */
export function buildUser(row: Row): AppUser {
  const roles = new Set<Role>(JSON.parse(row.roles || "[]"));
  if (row.is_admin === 1) roles.add("admin");
  const agencyId: string | null = row.agency_id ?? null;
  if (agencyId) roles.add("agent");
  return {
    uid: row.uid,
    email: String(row.email).toLowerCase(),
    name: row.name,
    roles: [...roles],
    schoolId: row.school_id ?? null,
    agencyId,
    hasProfile: row.has_profile === 1 || roles.has("admin") || roles.has("agent"),
  };
}

export async function loadUser(uid: string): Promise<AppUser | null> {
  const row = await queryOne("SELECT * FROM users WHERE uid = ?", [uid]);
  return row ? buildUser(row) : null;
}

export function profileOf(u: AppUser) {
  return { uid: u.uid, name: u.name, email: u.email, roles: u.roles, schoolId: u.schoolId ?? undefined, agencyId: u.agencyId ?? undefined };
}

// ---------- Middleware ----------

export async function requireAuth(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) throw new HttpError(401, "Not signed in");
  let uid: string;
  try {
    uid = await uidFromToken(token);
  } catch {
    throw new HttpError(401, "Your session has expired. Please sign in again.");
  }
  const user = await loadUser(uid);
  if (!user) throw new HttpError(401, "Account not found. Please sign in again.");
  req.user = user;
  next();
}

export function requireRole(...allowed: Role[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    const ok = allowed.some((r) => req.user?.roles.includes(r));
    if (!ok) throw new HttpError(403, "You don't have access to this");
    next();
  };
}
