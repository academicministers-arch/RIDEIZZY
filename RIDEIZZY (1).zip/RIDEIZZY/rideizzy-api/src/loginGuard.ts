// Slows down password guessing: after too many wrong passwords for one email from one address, wait a while.
const MAX_FAILS = 8;
const WINDOW_MS = 15 * 60_000;

const fails = new Map<string, { count: number; first: number }>();

function live(key: string) {
  const f = fails.get(key);
  if (f && Date.now() - f.first > WINDOW_MS) {
    fails.delete(key);
    return undefined;
  }
  return f;
}

export function isLocked(key: string) {
  return (live(key)?.count ?? 0) >= MAX_FAILS;
}

export function recordFailure(key: string) {
  const f = live(key);
  if (f) f.count++;
  else fails.set(key, { count: 1, first: Date.now() });
  if (fails.size > 10_000) for (const k of fails.keys()) live(k);
}

export function clearFailures(key: string) {
  fails.delete(key);
}
