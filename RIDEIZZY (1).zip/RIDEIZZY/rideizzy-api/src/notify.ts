import { randomUUID } from "node:crypto";
import { db, query } from "./db.js";

export async function notify(userId: string, title: string, body = "") {
  await db.execute({
    sql: "INSERT INTO notifications (notification_id, user_id, title, body) VALUES (?, ?, ?, ?)",
    args: [randomUUID(), userId, title, body],
  });
}

export async function notifyAdmins(title: string, body = "") {
  const admins = await query("SELECT uid FROM users WHERE is_admin = 1");
  await Promise.all(admins.map((a) => notify(a.uid, title, body)));
}
