import { createClient, type InArgs, type Transaction } from "@libsql/client";
import { config } from "./config.js";

export const db = createClient({ url: config.tursoUrl, authToken: config.tursoAuthToken });

export type Row = Record<string, any>;

function toRows(rs: { columns: string[]; rows: any[] }): Row[] {
  return rs.rows.map((row) => Object.fromEntries(rs.columns.map((c, i) => [c, row[i]])));
}

/** Run a SELECT and get plain objects back. Always pass values via `args` (never string-concatenate). */
export async function query(sql: string, args: InArgs = []): Promise<Row[]> {
  return toRows(await db.execute({ sql, args }));
}

export async function queryOne(sql: string, args: InArgs = []): Promise<Row | null> {
  return (await query(sql, args))[0] ?? null;
}

/** Same helpers, but inside an interactive transaction. */
export async function txQuery(tx: Transaction, sql: string, args: InArgs = []): Promise<Row[]> {
  return toRows(await tx.execute({ sql, args }));
}

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS users (
    uid           TEXT PRIMARY KEY,
    email         TEXT NOT NULL UNIQUE,
    name          TEXT NOT NULL DEFAULT '',
    password_hash TEXT NOT NULL,
    roles         TEXT NOT NULL DEFAULT '[]',
    has_profile   INTEGER NOT NULL DEFAULT 0,
    is_admin      INTEGER NOT NULL DEFAULT 0,
    agency_id     TEXT,
    school_id     TEXT,
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  )`,
  `CREATE TABLE IF NOT EXISTS agencies (
    agency_id     TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    contact_email TEXT NOT NULL DEFAULT '',
    invite_code   TEXT NOT NULL UNIQUE,
    status        TEXT NOT NULL DEFAULT 'invited',
    redeemed_by   TEXT,
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  )`,
  `CREATE TABLE IF NOT EXISTS rides (
    ride_id          TEXT PRIMARY KEY,
    rider_id         TEXT NOT NULL,
    driver_id        TEXT,
    pickup_lat       REAL NOT NULL, pickup_lng REAL NOT NULL, pickup_address TEXT NOT NULL,
    dropoff_lat      REAL NOT NULL, dropoff_lng REAL NOT NULL, dropoff_address TEXT NOT NULL,
    vehicle_class    TEXT NOT NULL,
    estimated_fare   REAL,
    fare             REAL,
    status           TEXT NOT NULL DEFAULT 'searching',
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_rides_rider ON rides(rider_id)`,
  `CREATE TABLE IF NOT EXISTS deliveries (
    delivery_id         TEXT PRIMARY KEY,
    requester_id        TEXT NOT NULL,
    driver_id           TEXT,
    pickup_lat          REAL NOT NULL, pickup_lng REAL NOT NULL, pickup_address TEXT NOT NULL,
    dropoff_lat         REAL NOT NULL, dropoff_lng REAL NOT NULL, dropoff_address TEXT NOT NULL,
    vehicle_class       TEXT NOT NULL,
    package_description TEXT NOT NULL,
    recipient_name      TEXT,
    recipient_phone     TEXT,
    estimated_fare      REAL,
    fare                REAL,
    status              TEXT NOT NULL DEFAULT 'searching',
    created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_deliveries_requester ON deliveries(requester_id)`,
  `CREATE TABLE IF NOT EXISTS travel_requests (
    request_id  TEXT PRIMARY KEY,
    rider_id    TEXT NOT NULL,
    origin      TEXT NOT NULL,
    destination TEXT NOT NULL,
    depart_date TEXT NOT NULL,
    passengers  INTEGER NOT NULL,
    cabin_class TEXT NOT NULL DEFAULT 'economy',
    status      TEXT NOT NULL DEFAULT 'pending',
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_travel_rider ON travel_requests(rider_id)`,
  `CREATE INDEX IF NOT EXISTS idx_travel_status ON travel_requests(status)`,
  `CREATE TABLE IF NOT EXISTS travel_quotes (
    quote_id    TEXT PRIMARY KEY,
    request_id  TEXT NOT NULL,
    agency_id   TEXT NOT NULL,
    agent_id    TEXT NOT NULL,
    price       REAL NOT NULL,
    currency    TEXT NOT NULL DEFAULT 'UGX',
    itinerary   TEXT NOT NULL,
    expires_at  TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'pending_approval',
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_quotes_request ON travel_quotes(request_id)`,
  `CREATE INDEX IF NOT EXISTS idx_quotes_status ON travel_quotes(status)`,
  `CREATE TABLE IF NOT EXISTS school_trips (
    trip_id         TEXT PRIMARY KEY,
    school_id       TEXT NOT NULL,
    requested_by    TEXT NOT NULL,
    destination     TEXT NOT NULL,
    date            TEXT NOT NULL,
    passenger_count INTEGER NOT NULL,
    vehicle_type    TEXT NOT NULL,
    notes           TEXT,
    status          TEXT NOT NULL DEFAULT 'requested',
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_trips_school ON school_trips(school_id)`,
  `CREATE TABLE IF NOT EXISTS notifications (
    notification_id TEXT PRIMARY KEY,
    user_id         TEXT NOT NULL,
    title           TEXT NOT NULL,
    body            TEXT NOT NULL DEFAULT '',
    read            INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at)`,
  `CREATE TABLE IF NOT EXISTS driver_locations (
    driver_id  TEXT PRIMARY KEY,
    lat        REAL NOT NULL,
    lng        REAL NOT NULL,
    heading    REAL,
    updated_at TEXT NOT NULL
  )`,
];

/**
 * Earlier versions used Google sign-in. Those `users` / `agencies` tables have a different shape and their
 * accounts have no password, so they are replaced. Rides, deliveries and other tables are left untouched.
 */
async function dropLegacyAuthTables() {
  const hasColumn = async (table: string, column: string) =>
    (await query(`SELECT 1 AS x FROM pragma_table_info('${table}') WHERE name = ?`, [column])).length > 0;
  if (await hasColumn("users", "google_sub")) await db.execute("DROP TABLE users");
  if ((await hasColumn("agencies", "contact_email")) && !(await hasColumn("agencies", "invite_code"))) {
    await db.execute("DROP TABLE agencies");
  }
}

export async function migrate() {
  await dropLegacyAuthTables();
  await db.batch(SCHEMA, "write");
}
