import "dotenv/config";

function required(name: string): string {
  const v = process.env[name]?.trim();
  if (!v) throw new Error(`Missing required environment variable ${name} (see .env.example)`);
  return v;
}

const list = (v: string | undefined) =>
  (v ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

export const config = {
  port: Number(process.env.PORT ?? 8000),
  tursoUrl: required("TURSO_DATABASE_URL"),
  tursoAuthToken: process.env.TURSO_AUTH_TOKEN?.trim() || undefined,
  sessionSecret: (() => {
    const s = required("SESSION_SECRET");
    if (s.length < 32) throw new Error("SESSION_SECRET must be at least 32 characters");
    return s;
  })(),
  allowedOrigins: list(process.env.ALLOWED_ORIGINS ?? "http://localhost:5173"),
  mapsKey: process.env.GOOGLE_MAPS_API_KEY?.trim() || undefined,
  placesRegion: (process.env.PLACES_REGION ?? "ug").toLowerCase(),
  trustProxy: process.env.TRUST_PROXY === "1",
  // Max sign-in / sign-up / invite attempts per minute per IP address.
  authRateLimit: Number(process.env.AUTH_RATE_LIMIT ?? 20),
};
