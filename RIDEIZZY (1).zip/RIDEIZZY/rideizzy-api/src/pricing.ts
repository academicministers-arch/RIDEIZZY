// Placeholder UGX rates. Tune these to your real pricing.
interface Rate { base: number; perKm: number; perMin: number; min: number }

export const RIDE_CLASSES = ["motorbike", "economy", "comfort", "xl"] as const;
export const DELIVERY_CLASSES = ["delivery_motorbike", "delivery_truck_small", "delivery_truck_large"] as const;

const RATES: Record<string, Rate> = {
  motorbike: { base: 1000, perKm: 700, perMin: 50, min: 2000 },
  economy: { base: 3000, perKm: 1500, perMin: 100, min: 5000 },
  comfort: { base: 4000, perKm: 2000, perMin: 150, min: 7000 },
  xl: { base: 5000, perKm: 2500, perMin: 200, min: 10000 },
  delivery_motorbike: { base: 2000, perKm: 800, perMin: 0, min: 3000 },
  delivery_truck_small: { base: 20000, perKm: 3000, perMin: 0, min: 40000 },
  delivery_truck_large: { base: 50000, perKm: 6000, perMin: 0, min: 100000 },
};

export interface Point { lat: number; lng: number }

function haversineKm(a: Point, b: Point) {
  const R = 6371;
  const rad = (d: number) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export function estimate(pickup: Point, dropoff: Point) {
  // Straight-line distance x 1.3 approximates road distance; ~22 km/h average in city traffic.
  const km = Math.round(haversineKm(pickup, dropoff) * 1.3 * 10) / 10;
  const minutes = Math.max(1, Math.round((km / 22) * 60));
  const estimates: Record<string, number> = {};
  for (const [key, r] of Object.entries(RATES)) {
    const raw = Math.max(r.min, r.base + r.perKm * km + r.perMin * minutes);
    estimates[key] = Math.round(raw / 500) * 500;
  }
  return { distance_km: km, duration_min: minutes, estimates };
}
