import cors from "cors";
import express from "express";
import { rateLimit } from "express-rate-limit";
import helmet from "helmet";
import { config } from "./config.js";
import { errorHandler } from "./http.js";
import { authRouter } from "./routes/auth.js";
import { mapsRouter } from "./routes/maps.js";
import { miscRouter } from "./routes/misc.js";
import { travelRouter } from "./routes/travel.js";
import { tripsRouter } from "./routes/trips.js";

export function createApp() {
  const app = express();
  if (config.trustProxy) app.set("trust proxy", 1);

  app.use(helmet());
  app.use(
    cors({
      origin(origin, cb) {
        // Allow non-browser callers (no Origin header) and the configured web origins.
        cb(null, !origin || config.allowedOrigins.includes(origin));
      },
      allowedHeaders: ["Authorization", "Content-Type"],
      methods: ["GET", "POST", "PUT", "OPTIONS"],
    })
  );
  app.use(express.json({ limit: "100kb" }));

  app.get("/health", (_req, res) => void res.json({ ok: true }));

  // Stricter limits where passwords or codes can be guessed.
  const strict = rateLimit({ windowMs: 60_000, limit: config.authRateLimit, standardHeaders: true, legacyHeaders: false });
  app.post(["/auth/login", "/auth/register", "/auth/redeem-invite"], strict);
  app.use(rateLimit({ windowMs: 60_000, limit: 600, standardHeaders: true, legacyHeaders: false }));

  app.use(authRouter, mapsRouter, tripsRouter, travelRouter, miscRouter);

  app.use((_req, res) => void res.status(404).json({ detail: "Not found" }));
  app.use(errorHandler);
  return app;
}
